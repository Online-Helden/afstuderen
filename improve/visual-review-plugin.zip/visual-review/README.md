# Visual Review

Visuele review plugin voor WordPress. Plaats pins of teken gebieden op je site om feedback te verzamelen, in NL of EN.

## Installatie

1. Upload de map `visual-review/` naar `/wp-content/plugins/`
   (of zip de map en upload via WP Admin → Plugins → Nieuwe plugin → Upload).
2. Activeer **Visual Review** via het Plugins menu.
3. Ga naar **Visual Review** in het admin menu (zijbalk).
4. Zet de toggle aan en kopieer je edit-code.

## Gebruik

### View mode (open voor iedereen wanneer plugin aan staat)
```
https://jouwsite.nl/?vr_review=1
https://jouwsite.nl/?vr_review=1&lang=en
```
Geen geheime code nodig. Iedereen kan bestaande opmerkingen zien.

### Edit mode (vereist code)
```
https://jouwsite.nl/?vr_review=1&vr_edit=JOUWCODE
https://jouwsite.nl/?vr_review=1&vr_edit=JOUWCODE&lang=en
```

### Werkt op elke pagina
Plak de query parameters achter elke URL van je site:
```
https://jouwsite.nl/diensten/?vr_review=1&vr_edit=CODE
https://jouwsite.nl/over-ons/?vr_review=1&lang=en
```

## Talen

- **NL = default**. Geen `lang` parameter? → Nederlands.
- `?lang=nl` → Nederlands.
- `?lang=en` → Engels.

Opmerkingen geschreven in NL worden opgeslagen in de kolom `note_nl`,
opmerkingen in EN in `note_en`. Beide kolommen worden onafhankelijk
opgehaald op basis van de gekozen taal — perfect voor een latere
auto-vertaal feature die je zelf bouwt.

## Database

Tabel `wp_vr_reviews` bevat:

| Kolom              | Type           | Doel                                   |
|--------------------|----------------|----------------------------------------|
| id                 | BIGINT         | PK                                     |
| page_url           | VARCHAR(500)   | Volledige URL waar marker geplaatst is |
| page_path          | VARCHAR(500)   | Pad zonder query (voor lookups)        |
| marker_type        | VARCHAR(20)    | `pin` of `area`                        |
| anchor_selector    | TEXT           | CSS selector van anchor element (info) |
| x_percent          | DECIMAL(7,4)   | X positie als % van document           |
| y_percent          | DECIMAL(7,4)   | Y positie als % van document           |
| width_percent      | DECIMAL(7,4)   | Alleen voor area markers               |
| height_percent     | DECIMAL(7,4)   | Alleen voor area markers               |
| viewport_width     | INT            | Schermbreedte op moment van plaatsen   |
| **note_nl**        | LONGTEXT       | Nederlandse opmerking                  |
| **note_en**        | LONGTEXT       | Engelse opmerking                      |
| author_name        | VARCHAR(190)   | Naam reviewer (optioneel)              |
| status             | VARCHAR(20)    | `open` of `resolved`                   |
| created_at         | DATETIME       | Aangemaakt                             |
| updated_at         | DATETIME       | Laatst bijgewerkt                      |

## REST API

Basis: `/wp-json/visual-review/v1`

| Endpoint              | Method | Auth                | Doel                  |
|-----------------------|--------|---------------------|-----------------------|
| `/reviews`            | GET    | Open (als enabled)  | Lijst voor `?path=`   |
| `/reviews`            | POST   | Edit code header    | Nieuwe review         |
| `/reviews/{id}`       | PATCH  | Edit code header    | Update note/status    |
| `/reviews/{id}`       | DELETE | Edit code header    | Verwijder review      |

Header voor schrijven: `X-VR-Edit-Code: jouwcode`
Query parameter voor taal: `?lang=nl|en`

## Responsive markers

Posities worden opgeslagen als percentage van de document scrollHeight × scrollWidth.
Bij resize berekent de plugin de pixel-positie automatisch opnieuw, dus markers
blijven op de juiste plek zitten op alle schermgroottes.

## Auto-vertaal hook (later)

Als je later wilt vertalen, hoef je alleen `note_nl` te lezen, vertalen, en in `note_en`
te schrijven (of vice versa). De frontend leest automatisch de juiste taalkolom.
