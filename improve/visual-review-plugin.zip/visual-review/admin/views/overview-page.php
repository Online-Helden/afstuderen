<?php
/**
 * Overview page — dedicated subtab for reviews management.
 * Always in English, focused exclusively on review actions.
 *
 * Vars: $code, $notice, $stats, $open_reviews, $pending_count, $is_locked
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="vr-wrap">

    <?php if ( $notice ) : ?>
        <div class="vr-notice vr-notice--<?php echo esc_attr( $notice['type'] ); ?>">
            <span class="vr-notice__dot"></span>
            <?php echo esc_html( $notice['msg'] ); ?>
        </div>
    <?php endif; ?>

    <header class="vr-hero vr-hero--compact">
        <div class="vr-hero__bar">
            <div class="vr-hero__eyebrow">
                <span class="vr-hero__logo">
                    <span class="vr-hero__logo-dot"></span>
                    <span class="vr-hero__logo-dot"></span>
                    <span class="vr-hero__logo-dot"></span>
                </span>
                Overview · v<?php echo esc_html( VR_VERSION ); ?>
            </div>
        </div>

        <h1 class="vr-hero__title">
            All <em>reviews</em>.
        </h1>
        <p class="vr-hero__sub">
            Every comment across every page. Translate to English, mark resolved, or open the page directly.
        </p>

        <div class="vr-hero__stats">
            <div class="vr-hero-stat">
                <span class="vr-hero-stat__num"><?php echo esc_html( $stats['total'] ); ?></span>
                <span class="vr-hero-stat__lbl">Total</span>
            </div>
            <div class="vr-hero-stat">
                <span class="vr-hero-stat__num vr-hero-stat__num--accent"><?php echo esc_html( $stats['open'] ); ?></span>
                <span class="vr-hero-stat__lbl">Open</span>
            </div>
            <div class="vr-hero-stat">
                <span class="vr-hero-stat__num"><?php echo esc_html( $stats['resolved'] ); ?></span>
                <span class="vr-hero-stat__lbl">Resolved</span>
            </div>
            <div class="vr-hero-stat">
                <span class="vr-hero-stat__num"><?php echo esc_html( $stats['pages'] ); ?></span>
                <span class="vr-hero-stat__lbl">Pages</span>
            </div>
        </div>
    </header>

    <div class="vr-grid">
        <section class="vr-card vr-card--reviews">
            <?php if ( ! empty( $open_reviews ) ) : ?>
                <div class="vr-translate-bar">
                    <div class="vr-translate-bar__info">
                        <?php if ( $is_locked ) : ?>
                            <span class="vr-translate-bar__status vr-translate-bar__status--locked">
                                <span class="vr-translate-bar__dot"></span>
                                Translation in progress...
                            </span>
                        <?php elseif ( $pending_count > 0 ) : ?>
                            <span class="vr-translate-bar__status">
                                <strong><?php echo esc_html( $pending_count ); ?></strong>
                                <?php echo $pending_count === 1 ? 'comment has' : 'comments have'; ?>
                                no English translation yet
                            </span>
                        <?php else : ?>
                            <span class="vr-translate-bar__status vr-translate-bar__status--done">
                                ✓ All comments translated
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="vr-translate-bar__actions">
                        <?php if ( $pending_count > 0 && ! $is_locked ) : ?>
                            <form method="post" style="display:inline;">
                                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                                <input type="hidden" name="vr_admin_action" value="translate_all">
                                <input type="hidden" name="vr_return_page" value="<?php echo esc_attr( VR_Admin::OVERVIEW_SLUG ); ?>">
                                <button type="submit" class="vr-btn vr-btn--primary"
                                    onclick="return confirm('Translate <?php echo esc_attr( $pending_count ); ?> comments? This may take a while.');">
                                    Translate all pending (<?php echo esc_html( $pending_count ); ?>)
                                </button>
                            </form>
                        <?php endif; ?>
                        <?php if ( $is_locked ) : ?>
                            <form method="post" style="display:inline;">
                                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                                <input type="hidden" name="vr_admin_action" value="release_lock">
                                <input type="hidden" name="vr_return_page" value="<?php echo esc_attr( VR_Admin::OVERVIEW_SLUG ); ?>">
                                <button type="submit" class="vr-btn vr-btn--ghost vr-btn--small"
                                    onclick="return confirm('Release lock? Only do this if a previous translation got stuck.');">
                                    Release lock
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ( ! empty( $open_reviews ) ) : ?>
                <div class="vr-global-lang">
                    <span class="vr-global-lang__label">Show all comments in:</span>
                    <div class="vr-global-lang__toggle" id="vr-global-lang-toggle">
                        <button type="button" class="vr-global-lang__btn" data-vr-global-lang="nl">
                            <span class="vr-global-lang__flag">🇳🇱</span> NL
                        </button>
                        <button type="button" class="vr-global-lang__btn is-active" data-vr-global-lang="en">
                            <span class="vr-global-lang__flag">🇬🇧</span> EN
                        </button>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ( empty( $open_reviews ) ) : ?>
                <div class="vr-empty">
                    <div class="vr-empty__icon">
                        <svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.5">
                            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
                        </svg>
                    </div>
                    <p class="vr-empty__text">No comments yet. Open a page with the edit link to add the first one.</p>
                </div>
            <?php else : ?>
                <?php foreach ( $open_reviews as $page ) : ?>
                    <details class="vr-review-group <?php echo ! empty( $page['is_general'] ) ? 'vr-review-group--general' : ''; ?>"
                        <?php echo $page['open'] > 0 ? 'open' : ''; ?>>
                        <summary class="vr-review-group__head">
                            <span class="vr-review-group__caret">▸</span>
                            <?php if ( ! empty( $page['is_general'] ) ) : ?>
                                <span class="vr-review-group__path vr-review-group__path--general">
                                    🌐 Site-wide feedback
                                </span>
                            <?php else : ?>
                                <span class="vr-review-group__path"><?php echo esc_html( $page['path'] ); ?></span>
                            <?php endif; ?>
                            <span class="vr-review-group__counts">
                                <?php if ( $page['open'] > 0 ) : ?>
                                    <span class="vr-pill vr-pill--open"><?php echo esc_html( $page['open'] ); ?> open</span>
                                <?php endif; ?>
                                <?php if ( $page['resolved'] > 0 ) : ?>
                                    <span class="vr-pill vr-pill--resolved"><?php echo esc_html( $page['resolved'] ); ?> resolved</span>
                                <?php endif; ?>
                            </span>
                            <?php if ( empty( $page['is_general'] ) ) : ?>
                                <a href="<?php echo esc_url( add_query_arg( array( 'vr_review' => 1, 'lang' => 'nl', 'vr_edit' => $code ), $page['url'] ) ); ?>"
                                   class="vr-review-group__link" target="_blank" rel="noopener"
                                   onclick="event.stopPropagation();">
                                    Open page ↗
                                </a>
                            <?php endif; ?>
                        </summary>

                        <div class="vr-review-list">
                            <?php foreach ( $page['reviews'] as $r ) :
                                $note_nl = trim( (string) $r->note_nl );
                                $note_en = trim( (string) $r->note_en );
                                $primary_note = $note_en !== '' ? $note_en : $note_nl;
                                $created = mysql2date( 'j M, H:i', $r->created_at );
                            ?>
                                <div class="vr-review vr-review--<?php echo esc_attr( $r->status ); ?>">
                                    <div class="vr-review__icon" title="<?php echo esc_attr( $r->marker_type ); ?>">
                                        <?php if ( $r->marker_type === 'general' ) : ?>
                                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>
                                        <?php elseif ( $r->marker_type === 'area' ) : ?>
                                            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="6" width="16" height="12" rx="1.5" stroke-dasharray="3 2"/></svg>
                                        <?php else : ?>
                                            <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>
                                        <?php endif; ?>
                                    </div>

                                    <div class="vr-review__body">
                                        <?php
                                        $has_nl = $note_nl !== '';
                                        $has_en = $note_en !== '';
                                        // Default tab: EN if available, otherwise NL
                                        $default_tab = $has_en ? 'en' : 'nl';
                                        ?>
                                        <div class="vr-review__tabs" data-default="<?php echo esc_attr( $default_tab ); ?>">
                                            <button type="button"
                                                class="vr-review__tab <?php echo $default_tab === 'nl' ? 'is-active' : ''; ?> <?php echo ! $has_nl ? 'is-empty' : ''; ?>"
                                                data-vr-tab="nl">
                                                NL
                                                <?php if ( ! $has_nl ) : ?><span class="vr-review__tab-mark">·</span><?php endif; ?>
                                            </button>
                                            <button type="button"
                                                class="vr-review__tab <?php echo $default_tab === 'en' ? 'is-active' : ''; ?> <?php echo ! $has_en ? 'is-empty' : ''; ?>"
                                                data-vr-tab="en">
                                                EN
                                                <?php if ( ! $has_en ) : ?><span class="vr-review__tab-mark">·</span><?php endif; ?>
                                            </button>
                                        </div>

                                        <div class="vr-review__panes">
                                            <div class="vr-review__pane <?php echo $default_tab === 'nl' ? 'is-active' : ''; ?>" data-vr-pane="nl">
                                                <?php if ( $has_nl ) : ?>
                                                    <p class="vr-review__note"><?php echo esc_html( $note_nl ); ?></p>
                                                <?php else : ?>
                                                    <p class="vr-review__note vr-review__note--missing">
                                                        <em>No Dutch version available.</em>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                            <div class="vr-review__pane <?php echo $default_tab === 'en' ? 'is-active' : ''; ?>" data-vr-pane="en">
                                                <?php if ( $has_en ) : ?>
                                                    <p class="vr-review__note"><?php echo esc_html( $note_en ); ?></p>
                                                <?php else : ?>
                                                    <p class="vr-review__note vr-review__note--missing">
                                                        <em>No English translation yet.<?php if ( $has_nl ) : ?> Use the Translate button to create one.<?php endif; ?></em>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="vr-review__meta">
                                            <span class="vr-pill vr-pill--<?php echo esc_attr( $r->status ); ?>">
                                                <?php echo $r->status === 'open' ? 'Open' : 'Resolved'; ?>
                                            </span>
                                            <?php
                                            $review_vp = isset( $r->viewport ) && in_array( $r->viewport, array( 'desktop', 'tablet', 'mobile' ), true )
                                                ? $r->viewport : 'desktop';
                                            $vp_labels = array(
                                                'desktop' => 'Desktop',
                                                'tablet'  => 'Tablet',
                                                'mobile'  => 'Mobile',
                                            );
                                            $vp_icons = array(
                                                'desktop' => '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="13" rx="2"/><path d="M8 21h8M12 18v3"/></svg>',
                                                'tablet'  => '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M11 18h2"/></svg>',
                                                'mobile'  => '<svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="currentColor" stroke-width="2"><rect x="7" y="3" width="10" height="18" rx="2"/><path d="M10 18h4"/></svg>',
                                            );
                                            ?>
                                            <span class="vr-vp-pill vr-vp-pill--<?php echo esc_attr( $review_vp ); ?>">
                                                <?php echo $vp_icons[ $review_vp ]; ?>
                                                <?php echo esc_html( $vp_labels[ $review_vp ] ); ?>
                                            </span>
                                            <?php if ( $r->author_name ) : ?>
                                                <span>· <?php echo esc_html( $r->author_name ); ?></span>
                                            <?php endif; ?>
                                            <span>· <?php echo esc_html( $created ); ?></span>
                                        </div>
                                    </div>

                                    <div class="vr-review__actions">
                                        <?php
                                        // Only show "open in context" for reviews that have a page location
                                        if ( $r->marker_type !== 'general' && ! empty( $page['url'] ) ) :
                                            $open_args = array(
                                                'vr_review' => 1,
                                                'lang'      => 'nl',
                                                'vr_edit'   => $code,
                                                'vr_focus'  => $r->id,
                                            );
                                            if ( $review_vp !== 'desktop' ) {
                                                $open_args['vr_view'] = $review_vp;
                                            }
                                            $open_url = add_query_arg( $open_args, $page['url'] );
                                        ?>
                                            <a href="<?php echo esc_url( $open_url ); ?>"
                                               target="_blank" rel="noopener"
                                               class="vr-btn vr-btn--ghost vr-btn--small vr-btn--open"
                                               title="Open page at this annotation (<?php echo esc_attr( $vp_labels[ $review_vp ] ); ?> view)">
                                                ↗
                                            </a>
                                        <?php endif; ?>
                                        <?php if ( $note_nl !== '' ) : ?>
                                            <form method="post" style="display:inline;">
                                                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                                                <input type="hidden" name="vr_admin_action" value="translate_one">
                                                <input type="hidden" name="review_id" value="<?php echo esc_attr( $r->id ); ?>">
                                                <input type="hidden" name="vr_return_page" value="<?php echo esc_attr( VR_Admin::OVERVIEW_SLUG ); ?>">
                                                <button type="submit"
                                                    class="vr-btn vr-btn--ghost vr-btn--small vr-btn--translate"
                                                    title="<?php echo $note_en === '' ? 'Translate NL to EN' : 'Re-translate (overwrites EN)'; ?>"
                                                    <?php disabled( $is_locked ); ?>
                                                    <?php if ( $note_en !== '' ) : ?>onclick="return confirm('Overwrite existing English translation?');"<?php endif; ?>>
                                                    <?php echo $note_en === '' ? 'Translate' : '↻'; ?>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <?php if ( $r->status === 'open' ) : ?>
                                            <form method="post" style="display:inline;">
                                                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                                                <input type="hidden" name="vr_admin_action" value="resolve_review">
                                                <input type="hidden" name="review_id" value="<?php echo esc_attr( $r->id ); ?>">
                                                <input type="hidden" name="vr_return_page" value="<?php echo esc_attr( VR_Admin::OVERVIEW_SLUG ); ?>">
                                                <button type="submit" class="vr-btn vr-btn--ghost vr-btn--small" title="Mark as resolved">✓</button>
                                            </form>
                                        <?php else : ?>
                                            <form method="post" style="display:inline;">
                                                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                                                <input type="hidden" name="vr_admin_action" value="reopen_review">
                                                <input type="hidden" name="review_id" value="<?php echo esc_attr( $r->id ); ?>">
                                                <input type="hidden" name="vr_return_page" value="<?php echo esc_attr( VR_Admin::OVERVIEW_SLUG ); ?>">
                                                <button type="submit" class="vr-btn vr-btn--ghost vr-btn--small" title="Reopen">↺</button>
                                            </form>
                                        <?php endif; ?>
                                        <form method="post" style="display:inline;">
                                            <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                                            <input type="hidden" name="vr_admin_action" value="delete_review">
                                            <input type="hidden" name="review_id" value="<?php echo esc_attr( $r->id ); ?>">
                                            <input type="hidden" name="vr_return_page" value="<?php echo esc_attr( VR_Admin::OVERVIEW_SLUG ); ?>">
                                            <button type="submit" class="vr-btn vr-btn--ghost vr-btn--small vr-btn--danger" title="Delete"
                                                onclick="return confirm('Delete this comment?');">×</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </div>

    <footer class="vr-foot">
        <span>Visual Review</span>
        <span class="vr-foot__sep">/</span>
        <span>Built by <a href="https://onlineheroes.agency" target="_blank" rel="noopener">Online Heroes</a></span>
    </footer>
</div>

<script>
(function () {
    var STORAGE_KEY = 'vr_overview_lang';

    function switchAllReviewsTo(lang) {
        // Update every review's tabs + panes
        document.querySelectorAll('.vr-review__tabs').forEach(function (tabsWrap) {
            tabsWrap.querySelectorAll('.vr-review__tab').forEach(function (b) {
                b.classList.toggle('is-active', b.getAttribute('data-vr-tab') === lang);
            });
            var panesWrap = tabsWrap.nextElementSibling;
            if (!panesWrap) return;
            panesWrap.querySelectorAll('.vr-review__pane').forEach(function (p) {
                p.classList.toggle('is-active', p.getAttribute('data-vr-pane') === lang);
            });
        });
        // Update the global toggle visual state
        document.querySelectorAll('.vr-global-lang__btn').forEach(function (b) {
            b.classList.toggle('is-active', b.getAttribute('data-vr-global-lang') === lang);
        });
        // Persist choice
        try { localStorage.setItem(STORAGE_KEY, lang); } catch (e) {}
    }

    // Apply saved preference on load
    try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved === 'nl' || saved === 'en') {
            switchAllReviewsTo(saved);
        }
    } catch (e) {}

    // Global toggle click
    document.addEventListener('click', function (e) {
        var gbtn = e.target.closest('.vr-global-lang__btn');
        if (gbtn) {
            switchAllReviewsTo(gbtn.getAttribute('data-vr-global-lang'));
            return;
        }

        // Per-review tab click (existing behaviour, also clears global preference
        // so individual choices stick until user clicks the global toggle again)
        var btn = e.target.closest('.vr-review__tab');
        if (!btn) return;
        var lang = btn.getAttribute('data-vr-tab');
        var tabsWrap = btn.closest('.vr-review__tabs');
        var panesWrap = tabsWrap && tabsWrap.nextElementSibling;
        if (!panesWrap) return;

        tabsWrap.querySelectorAll('.vr-review__tab').forEach(function (b) {
            b.classList.toggle('is-active', b === btn);
        });
        panesWrap.querySelectorAll('.vr-review__pane').forEach(function (p) {
            p.classList.toggle('is-active', p.getAttribute('data-vr-pane') === lang);
        });
    });
})();
</script>
