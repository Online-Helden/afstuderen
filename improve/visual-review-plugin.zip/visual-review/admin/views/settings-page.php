<?php
/**
 * Admin settings page template.
 * Vars: $enabled, $code, $view_url, $edit_url, $notice, $stats, $open_reviews
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="vr-wrap">

    <?php if ( $notice ) : ?>
        <div class="vr-notice vr-notice--<?php echo esc_attr( $notice['type'] ); ?>">
            <span class="vr-notice__dot"></span>
            <?php echo esc_html( $notice['msg'] ); ?>
        </div>
    <?php endif; ?>

    <header class="vr-hero">
        <div class="vr-hero__bar">
            <div class="vr-hero__eyebrow">
                <span class="vr-hero__logo">
                    <span class="vr-hero__logo-dot"></span>
                    <span class="vr-hero__logo-dot"></span>
                    <span class="vr-hero__logo-dot"></span>
                </span>
                Visual Review · v<?php echo esc_html( VR_VERSION ); ?>
            </div>

            <div class="vr-status">
                <span class="vr-status__value vr-status__value--<?php echo $enabled ? 'on' : 'off'; ?>">
                    <span class="vr-status__pulse"></span>
                    <?php echo $enabled ? 'Live' : 'Uitgeschakeld'; ?>
                </span>
            </div>
        </div>

        <h1 class="vr-hero__title">
            Visuele <em>feedback</em>.
        </h1>
        <p class="vr-hero__sub">
            Verzamel opmerkingen direct op je site. Plaats pins of teken gebieden,
            schrijf in NL of EN, los op en klaar.
        </p>

        <div class="vr-hero__cta">
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . VR_Admin::OVERVIEW_SLUG ) ); ?>"
               class="vr-btn vr-btn--primary">
                Open Reviews Overview →
            </a>
        </div>
    </header>

    <div class="vr-grid">

        <!-- Toggle card -->
        <section class="vr-card vr-card--primary">
            <div class="vr-card__head">
                <span class="vr-card__num">01</span>
                <h2 class="vr-card__title">Activeer review modus</h2>
            </div>
            <p class="vr-card__desc">
                Zet aan om feedback op je site mogelijk te maken.
                De URL parameters werken alleen als deze toggle aan staat.
            </p>

            <form method="post" class="vr-form">
                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                <input type="hidden" name="vr_admin_action" value="save_settings">

                <label class="vr-toggle">
                    <input type="checkbox" name="vr_enabled" value="1" <?php checked( $enabled ); ?>>
                    <span class="vr-toggle__track">
                        <span class="vr-toggle__thumb"></span>
                    </span>
                    <span class="vr-toggle__text">
                        <strong>Visual Review aan</strong>
                        <em>Vereist voor zowel view- als edit-mode</em>
                    </span>
                </label>

                <button type="submit" class="vr-btn vr-btn--primary">
                    Instellingen opslaan
                </button>
            </form>
        </section>

        <!-- Stats card -->
        <section class="vr-card vr-card--stats">
            <div class="vr-card__head">
                <span class="vr-card__num">·</span>
                <h2 class="vr-card__title">Activiteit</h2>
            </div>
            <div class="vr-stats">
                <div class="vr-stat">
                    <span class="vr-stat__num"><?php echo esc_html( $stats['total'] ); ?></span>
                    <span class="vr-stat__lbl">Totaal</span>
                </div>
                <div class="vr-stat">
                    <span class="vr-stat__num vr-stat__num--accent"><?php echo esc_html( $stats['open'] ); ?></span>
                    <span class="vr-stat__lbl">Open</span>
                </div>
                <div class="vr-stat">
                    <span class="vr-stat__num"><?php echo esc_html( $stats['resolved'] ); ?></span>
                    <span class="vr-stat__lbl">Opgelost</span>
                </div>
                <div class="vr-stat">
                    <span class="vr-stat__num"><?php echo esc_html( $stats['pages'] ); ?></span>
                    <span class="vr-stat__lbl">Pagina's</span>
                </div>
            </div>
        </section>

        <!-- Edit code card -->
        <section class="vr-card vr-card--code">
            <div class="vr-card__head">
                <span class="vr-card__num">02</span>
                <h2 class="vr-card__title">Edit code</h2>
            </div>
            <p class="vr-card__desc">
                Deze geheime code is vereist om edit-modus te openen.
                Deel hem alleen met mensen die mogen editen.
            </p>

            <div class="vr-code-box">
                <code class="vr-code"><?php echo esc_html( $code ); ?></code>
                <button type="button" class="vr-btn vr-btn--ghost" data-vr-copy="<?php echo esc_attr( $code ); ?>">
                    Kopiëren
                </button>
            </div>

            <form method="post" class="vr-form vr-form--inline">
                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                <input type="hidden" name="vr_admin_action" value="regen_code">
                <button type="submit" class="vr-btn vr-btn--ghost vr-btn--small"
                        onclick="return confirm('Bestaande code wordt ongeldig. Doorgaan?');">
                    ↻ Genereer nieuwe code
                </button>
            </form>
        </section>

        <!-- Modes card -->
        <section class="vr-card vr-card--modes">
            <div class="vr-card__head">
                <span class="vr-card__num">03</span>
                <h2 class="vr-card__title">Modi en URLs</h2>
            </div>

            <div class="vr-mode">
                <div class="vr-mode__top">
                    <span class="vr-mode__badge vr-mode__badge--view">View mode</span>
                    <span class="vr-mode__hint">Openbaar · alleen-lezen</span>
                </div>
                <div class="vr-url-box">
                    <code class="vr-url"><?php echo esc_html( $view_url ); ?></code>
                    <button type="button" class="vr-btn vr-btn--ghost vr-btn--small" data-vr-copy="<?php echo esc_attr( $view_url ); ?>">
                        Kopiëren
                    </button>
                </div>
                <p class="vr-mode__note">
                    Iedereen met deze link ziet bestaande opmerkingen.
                    Wissel taal met <code>&amp;lang=en</code>.
                </p>
            </div>

            <div class="vr-mode">
                <div class="vr-mode__top">
                    <span class="vr-mode__badge vr-mode__badge--edit">Edit mode</span>
                    <span class="vr-mode__hint">Vereist edit code</span>
                </div>
                <div class="vr-url-box">
                    <code class="vr-url"><?php echo esc_html( $edit_url ); ?></code>
                    <button type="button" class="vr-btn vr-btn--ghost vr-btn--small" data-vr-copy="<?php echo esc_attr( $edit_url ); ?>">
                        Kopiëren
                    </button>
                </div>
                <p class="vr-mode__note">
                    Pins en gebieden plaatsen, opmerkingen beheren.
                    NL editing → <code>note_nl</code>, EN editing → <code>note_en</code>.
                </p>
            </div>
        </section>

        <!-- AI translation settings -->
        <section class="vr-card vr-card--ai">
            <div class="vr-card__head">
                <span class="vr-card__num">04</span>
                <h2 class="vr-card__title">AI vertaling</h2>
            </div>
            <p class="vr-card__desc">
                Lokaal AI-model voor het vertalen van NL feedback naar EN instructies voor freelancers.
                Endpoint moet een OpenAI-compatible <code>/v1/chat/completions</code> aanroep accepteren.
            </p>

            <form method="post" class="vr-form">
                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                <input type="hidden" name="vr_admin_action" value="save_ai_settings">

                <div class="vr-ai-field">
                    <label class="vr-ai-field__label" for="vr_ai_endpoint">Endpoint URL</label>
                    <input type="url" id="vr_ai_endpoint" name="vr_ai_endpoint"
                        class="vr-ai-input"
                        value="<?php echo esc_attr( $ai_settings['endpoint'] ); ?>"
                        placeholder="https://your-tunnel.ngrok-free.dev/v1/chat/completions">
                </div>

                <div class="vr-ai-field">
                    <label class="vr-ai-field__label" for="vr_ai_model">Model naam</label>
                    <input type="text" id="vr_ai_model" name="vr_ai_model"
                        class="vr-ai-input"
                        value="<?php echo esc_attr( $ai_settings['model'] ); ?>"
                        placeholder="qwen3.5-9b">
                    <span class="vr-ai-field__hint">Wordt meegegeven aan het endpoint. Voor llama.cpp meestal niet kritisch.</span>
                </div>

                <div class="vr-ai-field">
                    <label class="vr-ai-field__label" for="vr_ai_prompt">Master prompt</label>
                    <textarea id="vr_ai_prompt" name="vr_ai_prompt" rows="8"
                        class="vr-ai-input vr-ai-input--textarea"><?php echo esc_textarea( $ai_settings['prompt'] ); ?></textarea>
                    <span class="vr-ai-field__hint">Houd kort. Lokaal model heeft beperkt context window. Vraag om JSON output met sleutel <code>translation</code>.</span>
                </div>

                <div class="vr-ai-actions">
                    <button type="submit" class="vr-btn vr-btn--primary">AI instellingen opslaan</button>
                </div>
            </form>

            <form method="post" class="vr-form vr-form--inline" style="margin-top: 10px;">
                <?php wp_nonce_field( 'vr_admin_save', 'vr_admin_nonce' ); ?>
                <input type="hidden" name="vr_admin_action" value="reset_ai_prompt">
                <button type="submit" class="vr-btn vr-btn--ghost vr-btn--small"
                    onclick="return confirm('Master prompt terugzetten op standaard?');">
                    ↻ Reset prompt naar standaard
                </button>
            </form>
        </section>

        <!-- How to use card -->
        <section class="vr-card vr-card--guide">
            <div class="vr-card__head">
                <span class="vr-card__num">05</span>
                <h2 class="vr-card__title">URL parameters</h2>
            </div>
            <table class="vr-params">
                <tr>
                    <td><code>?vr_review=1</code></td>
                    <td>Activeert review overlay (view mode).</td>
                </tr>
                <tr>
                    <td><code>&amp;lang=nl</code></td>
                    <td>Nederlands (default).</td>
                </tr>
                <tr>
                    <td><code>&amp;lang=en</code></td>
                    <td>Engels.</td>
                </tr>
                <tr>
                    <td><code>&amp;vr_edit=CODE</code></td>
                    <td>Edit modus met geheime code.</td>
                </tr>
            </table>
        </section>

    </div>

    <footer class="vr-foot">
        <span>Visual Review</span>
        <span class="vr-foot__sep">/</span>
        <span>Built by <a href="https://onlineheroes.agency" target="_blank" rel="noopener">Online Heroes</a></span>
    </footer>
</div>

<script>
document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-vr-copy]');
    if (!btn) return;
    var text = btn.getAttribute('data-vr-copy');
    navigator.clipboard.writeText(text).then(function () {
        var orig = btn.textContent;
        btn.textContent = '✓ Gekopieerd';
        btn.classList.add('vr-btn--copied');
        setTimeout(function () {
            btn.textContent = orig;
            btn.classList.remove('vr-btn--copied');
        }, 1400);
    });
});
</script>
