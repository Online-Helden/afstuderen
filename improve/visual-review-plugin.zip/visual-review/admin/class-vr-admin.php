<?php
/**
 * Admin interface voor Visual Review.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VR_Admin {

    const MENU_SLUG     = 'visual-review';
    const OVERVIEW_SLUG = 'visual-review-overview';

    public function __construct() {
        add_action( 'admin_menu',            array( $this, 'register_menu' ) );
        add_action( 'admin_init',            array( $this, 'handle_post' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
    }

    public function register_menu() {
        // Top-level: Settings
        add_menu_page(
            'Visual Review',
            'Visual Review',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_page' ),
            'dashicons-format-chat',
            58
        );

        // Rename the auto-generated first submenu item to "Settings"
        add_submenu_page(
            self::MENU_SLUG,
            'Settings',
            'Settings',
            'manage_options',
            self::MENU_SLUG,
            array( $this, 'render_page' )
        );

        // Subtab: Overview (English, focused on reviews)
        add_submenu_page(
            self::MENU_SLUG,
            'Reviews Overview',
            'Overview',
            'manage_options',
            self::OVERVIEW_SLUG,
            array( $this, 'render_overview_page' )
        );
    }

    public function enqueue_assets( $hook ) {
        $is_settings = 'toplevel_page_' . self::MENU_SLUG === $hook;
        $is_overview = strpos( $hook, self::OVERVIEW_SLUG ) !== false;

        if ( ! $is_settings && ! $is_overview ) {
            return;
        }
        wp_enqueue_style(
            'vr-admin',
            VR_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            VR_VERSION
        );
    }

    public function handle_post() {
        if ( ! isset( $_POST['vr_admin_action'] ) ) {
            return;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        check_admin_referer( 'vr_admin_save', 'vr_admin_nonce' );

        $action = sanitize_text_field( wp_unslash( $_POST['vr_admin_action'] ) );

        if ( 'save_settings' === $action ) {
            VR_Settings::update( array(
                'enabled' => ! empty( $_POST['vr_enabled'] ),
            ) );
            $this->add_notice( 'Instellingen opgeslagen.', 'success' );
        }

        if ( 'save_ai_settings' === $action ) {
            $endpoint = isset( $_POST['vr_ai_endpoint'] ) ? esc_url_raw( wp_unslash( $_POST['vr_ai_endpoint'] ) ) : '';
            $model    = isset( $_POST['vr_ai_model'] ) ? sanitize_text_field( wp_unslash( $_POST['vr_ai_model'] ) ) : '';
            $prompt   = isset( $_POST['vr_ai_prompt'] ) ? trim( wp_unslash( $_POST['vr_ai_prompt'] ) ) : '';

            VR_Settings::update( array(
                'ai_endpoint' => $endpoint,
                'ai_model'    => $model,
                'ai_prompt'   => $prompt,
            ) );
            $this->add_notice( 'AI instellingen opgeslagen.', 'success' );
        }

        if ( 'reset_ai_prompt' === $action ) {
            VR_Settings::update( array(
                'ai_prompt' => VR_Settings::default_prompt(),
            ) );
            $this->add_notice( 'Master prompt teruggezet op standaard.', 'success' );
        }

        if ( 'translate_one' === $action ) {
            $id = isset( $_POST['review_id'] ) ? intval( $_POST['review_id'] ) : 0;
            if ( $id ) {
                if ( ! VR_Translator::acquire_lock() ) {
                    $this->add_notice( 'Er loopt al een vertaling. Probeer het zo opnieuw.', 'error' );
                } else {
                    $result = VR_Translator::translate_review( $id );
                    VR_Translator::release_lock();
                    if ( $result['success'] ) {
                        $this->add_notice( 'Vertaald.', 'success' );
                    } else {
                        $this->add_notice( 'Vertaling mislukt: ' . $result['message'], 'error' );
                    }
                }
            }
        }

        if ( 'translate_all' === $action ) {
            if ( ! VR_Translator::acquire_lock() ) {
                $this->add_notice( 'Er loopt al een vertaling. Probeer het zo opnieuw.', 'error' );
            } else {
                $result = $this->translate_all_pending();
                VR_Translator::release_lock();
                $this->add_notice( $result['message'], $result['type'] );
            }
        }

        if ( 'release_lock' === $action ) {
            VR_Translator::release_lock();
            $this->add_notice( 'Lock vrijgegeven.', 'success' );
        }

        if ( 'regen_code' === $action ) {
            VR_Settings::update( array(
                'edit_code' => VR_Database::generate_code(),
            ) );
            $this->add_notice( 'Nieuwe edit code gegenereerd.', 'success' );
        }

        if ( 'resolve_review' === $action ) {
            $id = isset( $_POST['review_id'] ) ? intval( $_POST['review_id'] ) : 0;
            if ( $id ) {
                VR_Database::update( $id, array( 'status' => 'resolved' ) );
                $this->add_notice( 'Opmerking gemarkeerd als opgelost.', 'success' );
            }
        }

        if ( 'reopen_review' === $action ) {
            $id = isset( $_POST['review_id'] ) ? intval( $_POST['review_id'] ) : 0;
            if ( $id ) {
                VR_Database::update( $id, array( 'status' => 'open' ) );
                $this->add_notice( 'Opmerking heropend.', 'success' );
            }
        }

        if ( 'delete_review' === $action ) {
            $id = isset( $_POST['review_id'] ) ? intval( $_POST['review_id'] ) : 0;
            if ( $id ) {
                VR_Database::delete( $id );
                $this->add_notice( 'Opmerking verwijderd.', 'success' );
            }
        }

        // Redirect back to where the form came from
        $return_page = isset( $_POST['vr_return_page'] )
            ? sanitize_text_field( wp_unslash( $_POST['vr_return_page'] ) )
            : self::MENU_SLUG;
        if ( ! in_array( $return_page, array( self::MENU_SLUG, self::OVERVIEW_SLUG ), true ) ) {
            $return_page = self::MENU_SLUG;
        }
        wp_safe_redirect( admin_url( 'admin.php?page=' . $return_page ) );
        exit;
    }

    private function add_notice( $msg, $type = 'success' ) {
        set_transient( 'vr_admin_notice', array( 'msg' => $msg, 'type' => $type ), 30 );
    }

    private function get_notice() {
        $n = get_transient( 'vr_admin_notice' );
        if ( $n ) {
            delete_transient( 'vr_admin_notice' );
        }
        return $n;
    }

    public function render_page() {
        $settings     = VR_Settings::get_all();
        $code         = VR_Settings::get_edit_code();
        $enabled      = ! empty( $settings['enabled'] );
        $notice       = $this->get_notice();
        $base_url     = home_url( '/' );
        $view_url     = add_query_arg( array( 'vr_review' => 1, 'lang' => 'nl' ), $base_url );
        $edit_url     = add_query_arg( array( 'vr_review' => 1, 'lang' => 'nl', 'vr_edit' => $code ), $base_url );
        $stats        = $this->get_stats();
        $ai_settings  = array(
            'endpoint' => VR_Settings::get( 'ai_endpoint' ),
            'model'    => VR_Settings::get( 'ai_model' ),
            'prompt'   => VR_Settings::get( 'ai_prompt' ),
        );

        include VR_PLUGIN_DIR . 'admin/views/settings-page.php';
    }

    public function render_overview_page() {
        $code          = VR_Settings::get_edit_code();
        $notice        = $this->get_notice();
        $stats         = $this->get_stats();
        $open_reviews  = $this->get_open_reviews();
        $pending_count = $this->count_pending_translations();
        $is_locked     = VR_Translator::is_locked();

        include VR_PLUGIN_DIR . 'admin/views/overview-page.php';
    }

    /**
     * Tel reviews die NL content hebben maar geen EN content.
     */
    private function count_pending_translations() {
        global $wpdb;
        $table = VR_Database::table_name();
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table}
             WHERE note_nl IS NOT NULL AND note_nl != ''
               AND (note_en IS NULL OR note_en = '')"
        );
    }

    /**
     * Vertaal alle reviews die NL content hebben maar nog geen EN content.
     * Sequentieel — één voor één — om het lokale model niet te overbelasten.
     */
    private function translate_all_pending() {
        global $wpdb;
        $table = VR_Database::table_name();

        $ids = $wpdb->get_col(
            "SELECT id FROM {$table}
             WHERE note_nl IS NOT NULL AND note_nl != ''
               AND (note_en IS NULL OR note_en = '')
             ORDER BY created_at ASC"
        );

        if ( empty( $ids ) ) {
            return array( 'type' => 'success', 'message' => 'Niets om te vertalen.' );
        }

        // Verleng PHP execution time waar mogelijk (lokaal model kan traag zijn)
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 );
        }

        $ok     = 0;
        $failed = 0;
        $first_err = '';

        foreach ( $ids as $id ) {
            $result = VR_Translator::translate_review( intval( $id ) );
            if ( $result['success'] ) {
                $ok++;
            } else {
                $failed++;
                if ( $first_err === '' ) {
                    $first_err = $result['message'];
                }
                // Bij een verbindings/endpoint fout: stoppen, anders blijven we hangen
                if ( stripos( $result['message'], 'verbinding' ) !== false
                     || stripos( $result['message'], 'endpoint' ) !== false ) {
                    break;
                }
            }
        }

        $msg = $ok . ' vertaald';
        if ( $failed > 0 ) {
            $msg .= ', ' . $failed . ' mislukt';
            if ( $first_err ) {
                $msg .= ' (eerste fout: ' . $first_err . ')';
            }
        }

        return array(
            'type'    => $failed === 0 ? 'success' : ( $ok === 0 ? 'error' : 'success' ),
            'message' => $msg,
        );
    }

    private function get_stats() {
        global $wpdb;
        $table = VR_Database::table_name();
        return array(
            'total'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
            'open'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'open'" ),
            'resolved' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'resolved'" ),
            'pages'    => (int) $wpdb->get_var( "SELECT COUNT(DISTINCT page_path) FROM {$table}" ),
        );
    }

    /**
     * Haal alle reviews op gegroepeerd per pagina, met open eerst.
     */
    private function get_open_reviews() {
        global $wpdb;
        $table = VR_Database::table_name();
        $rows  = $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY status ASC, created_at DESC LIMIT 200"
        );

        $grouped = array();
        foreach ( $rows as $r ) {
            $key = $r->page_path;
            if ( ! isset( $grouped[ $key ] ) ) {
                $grouped[ $key ] = array(
                    'path'       => $r->page_path,
                    'url'        => $r->page_url,
                    'reviews'    => array(),
                    'open'       => 0,
                    'resolved'   => 0,
                    'is_general' => ( $r->page_path === '*' ),
                );
            }
            $grouped[ $key ]['reviews'][] = $r;
            if ( $r->status === 'open' ) {
                $grouped[ $key ]['open']++;
            } else {
                $grouped[ $key ]['resolved']++;
            }
        }

        // Sort: site-wide (general) groups first, then pages with most open items.
        uasort( $grouped, function( $a, $b ) {
            if ( $a['is_general'] !== $b['is_general'] ) {
                return $a['is_general'] ? -1 : 1;
            }
            if ( $a['open'] !== $b['open'] ) {
                return $b['open'] - $a['open'];
            }
            return count( $b['reviews'] ) - count( $a['reviews'] );
        } );

        return $grouped;
    }
}
