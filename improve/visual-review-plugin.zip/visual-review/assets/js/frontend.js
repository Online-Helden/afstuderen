/* =============================================================
   Visual Review · Frontend
   ------------------------------------------------------------
   Anchor strategy (industry standard, à la Hypothesis/SitePing):
     1. CSS selector (shortest unique, generated finder-style)
     2. XPath fallback (DOM structure persists if classes change)
     3. Position stored as % of anchor element's bounding box
     4. Document-% as last resort if anchor disappears entirely
   Marker resolution:
     - Try CSS selector → if hit, position via element rect
     - Try XPath → if hit, position via element rect
     - Use document fallback %
     - ResizeObserver per anchor element keeps markers in sync
   ============================================================= */

(function () {
    'use strict';

    if (typeof VR_DATA === 'undefined') return;

    var DATA = window.VR_DATA;
    var IS_EDIT = !!DATA.editMode;
    var I = DATA.i18n;

    var state = {
        reviews: [],
        selectedId: null,
        placing: null,
        anchorMap: {}
    };

    /* =========================================================
       DOM helpers
       ========================================================= */
    function $(sel, ctx) { return (ctx || document).querySelector(sel); }
    function el(tag, attrs, children) {
        var node = document.createElement(tag);
        if (attrs) {
            Object.keys(attrs).forEach(function (k) {
                if (k === 'class') node.className = attrs[k];
                else if (k === 'html') node.innerHTML = attrs[k];
                else if (k === 'text') node.textContent = attrs[k];
                else if (k.indexOf('on') === 0) node.addEventListener(k.slice(2), attrs[k]);
                else if (k === 'style' && typeof attrs[k] === 'object') Object.assign(node.style, attrs[k]);
                else node.setAttribute(k, attrs[k]);
            });
        }
        if (children) (Array.isArray(children) ? children : [children]).forEach(function (c) {
            if (c == null) return;
            node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
        });
        return node;
    }
    function escHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    var NAME_STORAGE_KEY = 'vr_reviewer_name';
    function getStoredName() {
        try {
            var v = localStorage.getItem(NAME_STORAGE_KEY);
            return v || '';
        } catch (e) { return ''; }
    }
    function setStoredName(name) {
        try {
            if (name && name.trim()) {
                localStorage.setItem(NAME_STORAGE_KEY, name.trim());
            }
        } catch (e) {}
    }
    function isOurOwnElement(node) {
        if (!node) return false;
        var n = node;
        while (n && n !== document.body) {
            if (n.classList && (
                n.classList.contains('vr-marker') ||
                n.classList.contains('vr-bar') ||
                n.classList.contains('vr-panel') ||
                n.classList.contains('vr-placement') ||
                n.classList.contains('vr-placement-rect') ||
                n.classList.contains('vr-hint') ||
                n.classList.contains('vr-toast') ||
                n.id === 'vr-root'
            )) return true;
            n = n.parentNode;
        }
        return false;
    }

    /* =========================================================
       API
       ========================================================= */
    function apiFetch(path, opts) {
        opts = opts || {};
        opts.headers = Object.assign({
            'Content-Type': 'application/json',
            'X-WP-Nonce': DATA.nonce
        }, opts.headers || {});
        if (IS_EDIT && DATA.editCode) {
            opts.headers['X-VR-Edit-Code'] = DATA.editCode;
        }

        // 30s timeout — if a request hangs longer something is genuinely wrong
        var controller = null;
        if (typeof AbortController !== 'undefined') {
            controller = new AbortController();
            opts.signal = controller.signal;
            setTimeout(function () { controller.abort(); }, 30000);
        }

        return fetch(DATA.restUrl + path, opts).then(function (r) {
            if (!r.ok) {
                return r.text().then(function (txt) {
                    throw new Error('HTTP ' + r.status + (txt ? ': ' + txt.substring(0, 200) : ''));
                });
            }
            return r.json();
        });
    }
    function loadReviews() {
        var url = '/reviews?path=' + encodeURIComponent(DATA.pagePath) + '&lang=' + DATA.lang;
        return apiFetch(url).then(function (rows) {
            state.reviews = rows || [];
            renderMarkers();
            updateCount();
            maybeFocusReviewFromUrl();
        });
    }

    function maybeFocusReviewFromUrl() {
        try {
            var u = new URL(window.location.href);
            var focusId = parseInt(u.searchParams.get('vr_focus'), 10);
            if (!focusId) return;
            var target = state.reviews.find(function (r) { return r.id === focusId; });
            if (!target) return;

            // Open the review panel after a brief delay so the page has time to lay out
            setTimeout(function () {
                openReview(target.id);
                if (target.marker_type !== 'general') {
                    var pos = resolveReviewPosition(target);
                    window.scrollTo({ top: pos.y - window.innerHeight / 3, behavior: 'smooth' });
                }
            }, 400);
        } catch (e) {}
    }
    function createReview(payload) {
        return apiFetch('/reviews?lang=' + DATA.lang, {
            method: 'POST', body: JSON.stringify(payload)
        });
    }
    function updateReview(id, payload) {
        return apiFetch('/reviews/' + id + '?lang=' + DATA.lang, {
            method: 'PATCH', body: JSON.stringify(payload)
        });
    }
    function deleteReviewApi(id) {
        return apiFetch('/reviews/' + id, { method: 'DELETE' });
    }

    /* =========================================================
       SELECTOR GENERATION (finder-style)
       Walks up DOM building shortest unique CSS selector.
       ========================================================= */

    function isSkipClass(c) {
        if (!c) return true;
        if (c.startsWith('vr-')) return true;
        // unstable hashed/auto-generated class names
        if (/^css-[a-z0-9]{5,}$/i.test(c)) return true;
        if (/^[a-z]{1,3}_[a-zA-Z0-9]{6,}$/.test(c)) return true; // emotion / styled
        if (/^sc-[a-zA-Z0-9]{6,}$/.test(c)) return true;          // styled-components
        return false;
    }

    function getElementSignature(node) {
        var sig = node.tagName.toLowerCase();
        if (node.className && typeof node.className === 'string') {
            var classes = node.className.trim().split(/\s+/).filter(function (c) { return !isSkipClass(c); });
            if (classes.length) {
                sig += '.' + classes.slice(0, 3).map(function (c) { return CSS.escape(c); }).join('.');
            }
        }
        var parent = node.parentElement;
        if (parent) {
            var same = Array.prototype.filter.call(parent.children, function (n) { return n.tagName === node.tagName; });
            if (same.length > 1) {
                sig += ':nth-of-type(' + (same.indexOf(node) + 1) + ')';
            }
        }
        return sig;
    }

    function buildCssSelector(node) {
        if (!node || node.nodeType !== 1) return null;
        if (node === document.body) return 'body';
        if (node === document.documentElement) return 'html';
        if (node.id) {
            try {
                if (document.querySelectorAll('#' + CSS.escape(node.id)).length === 1) {
                    return '#' + CSS.escape(node.id);
                }
            } catch (e) {}
        }
        var parts = [];
        var cur = node, depth = 0;
        while (cur && cur.nodeType === 1 && cur !== document.body && depth < 8) {
            parts.unshift(getElementSignature(cur));
            var test = parts.join(' > ');
            try {
                var matches = document.querySelectorAll(test);
                if (matches.length === 1 && matches[0] === node) return test;
            } catch (e) {}
            if (cur.parentElement && cur.parentElement.id) {
                try {
                    if (document.querySelectorAll('#' + CSS.escape(cur.parentElement.id)).length === 1) {
                        parts.unshift('#' + CSS.escape(cur.parentElement.id));
                        var test2 = parts.join(' > ');
                        var m2 = document.querySelectorAll(test2);
                        if (m2.length === 1 && m2[0] === node) return test2;
                        break;
                    }
                } catch (e) {}
            }
            cur = cur.parentElement;
            depth++;
        }
        var withBody = ['body'].concat(parts).join(' > ');
        try {
            var mb = document.querySelectorAll(withBody);
            if (mb.length === 1 && mb[0] === node) return withBody;
        } catch (e) {}
        return null;
    }

    function buildXPath(node) {
        if (!node || node.nodeType !== 1) return null;
        if (node.id) {
            try {
                if (document.querySelectorAll('#' + CSS.escape(node.id)).length === 1) {
                    return '//*[@id="' + node.id + '"]';
                }
            } catch (e) {}
        }
        var parts = [];
        var cur = node;
        while (cur && cur.nodeType === 1 && cur !== document.documentElement) {
            var idx = 1, sib = cur.previousElementSibling;
            while (sib) {
                if (sib.tagName === cur.tagName) idx++;
                sib = sib.previousElementSibling;
            }
            parts.unshift(cur.tagName.toLowerCase() + '[' + idx + ']');
            cur = cur.parentElement;
        }
        return '/' + parts.join('/');
    }
    function findByXPath(xpath) {
        try {
            var res = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
            return res.singleNodeValue;
        } catch (e) { return null; }
    }

    /* =========================================================
       Anchor encoding (JSON in existing DB column)
       v2 schema: { v:2, css, xp, fx, fy, fw?, fh? }
       v1 backward compat: "selector|FB:x,y[,w,h]"
       ========================================================= */
    function encodeAnchor(a) {
        if (!a) return null;
        return JSON.stringify({
            v: 2,
            css: a.css || null,
            xp:  a.xpath || null,
            fx:  +(a.fbX || 0).toFixed(4),
            fy:  +(a.fbY || 0).toFixed(4),
            fw:  a.fbW != null ? +a.fbW.toFixed(4) : null,
            fh:  a.fbH != null ? +a.fbH.toFixed(4) : null
        });
    }
    function decodeAnchor(raw) {
        if (!raw) return null;
        if (raw.charAt(0) === '{') {
            try {
                var d = JSON.parse(raw);
                return { css: d.css || null, xpath: d.xp || null,
                         fbX: d.fx, fbY: d.fy, fbW: d.fw, fbH: d.fh };
            } catch (e) {}
        }
        var idx = raw.indexOf('|FB:');
        if (idx !== -1) {
            var nums = raw.substring(idx + 4).split(',').map(parseFloat);
            return { css: raw.substring(0, idx) || null, xpath: null,
                     fbX: nums[0], fbY: nums[1],
                     fbW: nums.length > 2 ? nums[2] : null,
                     fbH: nums.length > 3 ? nums[3] : null };
        }
        return { css: raw, xpath: null, fbX: null, fbY: null, fbW: null, fbH: null };
    }

    /* =========================================================
       Anchor element selection
       ========================================================= */
    function getElementsAtPoint(clientX, clientY) {
        if (typeof document.elementsFromPoint === 'function') {
            return document.elementsFromPoint(clientX, clientY).filter(function (e) { return !isOurOwnElement(e); });
        }
        var s = document.elementFromPoint(clientX, clientY);
        return s && !isOurOwnElement(s) ? [s] : [];
    }

    /**
     * Smart anchor pick — prefer:
     *   1. element with stable id
     *   2. smallest non-trivial element under cursor (most specific)
     */
    function pickAnchorForPin(elements) {
        if (!elements || !elements.length) return null;
        for (var i = 0; i < elements.length; i++) {
            if (elements[i].id) return elements[i];
        }
        var best = null, bestArea = Infinity;
        for (var j = 0; j < elements.length; j++) {
            var c = elements[j];
            if (c === document.body || c === document.documentElement) continue;
            var r = c.getBoundingClientRect();
            if (r.width < 10 || r.height < 10) continue;
            var area = r.width * r.height;
            if (area < bestArea) { bestArea = area; best = c; }
        }
        return best;
    }

    function pickAnchorForArea(centerCX, centerCY, areaPageRect) {
        var candidates = getElementsAtPoint(centerCX, centerCY);
        for (var i = 0; i < candidates.length; i++) {
            var c = candidates[i];
            if (c === document.body || c === document.documentElement) continue;
            var r = c.getBoundingClientRect();
            var pl = r.left + window.pageXOffset, pt = r.top + window.pageYOffset;
            if (areaPageRect.x >= pl - 2 && areaPageRect.y >= pt - 2 &&
                (areaPageRect.x + areaPageRect.w) <= (pl + r.width + 2) &&
                (areaPageRect.y + areaPageRect.h) <= (pt + r.height + 2)) {
                return c;
            }
        }
        return pickAnchorForPin(candidates);
    }

    /* =========================================================
       Resolve review → page coordinates
       ========================================================= */
    function resolveAnchorElement(anchor) {
        if (!anchor) return null;
        if (anchor.css) {
            try {
                var els = document.querySelectorAll(anchor.css);
                if (els.length >= 1) return els[0];
            } catch (e) {}
        }
        if (anchor.xpath) {
            var n = findByXPath(anchor.xpath);
            if (n) return n;
        }
        return null;
    }
    function getDocSize() {
        return {
            width:  Math.max(document.documentElement.scrollWidth,  document.body.scrollWidth),
            height: Math.max(document.documentElement.scrollHeight, document.body.scrollHeight)
        };
    }
    function resolveReviewPosition(review) {
        var anchor = decodeAnchor(review.anchor_selector);
        var element = resolveAnchorElement(anchor);

        if (element) {
            var rect = element.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
                var pl = rect.left + window.pageXOffset;
                var pt = rect.top + window.pageYOffset;
                return {
                    x: pl + (review.x_percent / 100) * rect.width,
                    y: pt + (review.y_percent / 100) * rect.height,
                    width:  review.width_percent  != null ? (review.width_percent  / 100) * rect.width  : null,
                    height: review.height_percent != null ? (review.height_percent / 100) * rect.height : null,
                    anchor: element,
                    anchored: true
                };
            }
        }
        var docSize = getDocSize();
        var fbX = anchor && anchor.fbX != null ? anchor.fbX : review.x_percent;
        var fbY = anchor && anchor.fbY != null ? anchor.fbY : review.y_percent;
        var fbW = anchor && anchor.fbW != null ? anchor.fbW : (review.width_percent  != null ? review.width_percent  : null);
        var fbH = anchor && anchor.fbH != null ? anchor.fbH : (review.height_percent != null ? review.height_percent : null);
        return {
            x: (fbX / 100) * docSize.width,
            y: (fbY / 100) * docSize.height,
            width:  fbW != null ? (fbW / 100) * docSize.width  : null,
            height: fbH != null ? (fbH / 100) * docSize.height : null,
            anchor: null,
            anchored: false
        };
    }

    /* =========================================================
       BUILD payloads
       ========================================================= */
    function buildPinPayload(cx, cy) {
        var pageX = cx + window.pageXOffset;
        var pageY = cy + window.pageYOffset;
        var docSize = getDocSize();
        var docX = (pageX / docSize.width) * 100;
        var docY = (pageY / docSize.height) * 100;

        var anchor = pickAnchorForPin(getElementsAtPoint(cx, cy));
        if (anchor) {
            var rect = anchor.getBoundingClientRect();
            var pl = rect.left + window.pageXOffset;
            var pt = rect.top + window.pageYOffset;
            var xWithin = Math.max(0, Math.min(100, ((pageX - pl) / rect.width) * 100));
            var yWithin = Math.max(0, Math.min(100, ((pageY - pt) / rect.height) * 100));
            return {
                marker_type: 'pin',
                anchor_selector: encodeAnchor({
                    css: buildCssSelector(anchor), xpath: buildXPath(anchor),
                    fbX: docX, fbY: docY
                }),
                x_percent: xWithin, y_percent: yWithin
            };
        }
        return {
            marker_type: 'pin',
            anchor_selector: encodeAnchor({ fbX: docX, fbY: docY }),
            x_percent: docX, y_percent: docY
        };
    }

    function buildAreaPayload(sCX, sCY, eCX, eCY) {
        var sPX = sCX + window.pageXOffset, sPY = sCY + window.pageYOffset;
        var ePX = eCX + window.pageXOffset, ePY = eCY + window.pageYOffset;
        var x = Math.min(sPX, ePX), y = Math.min(sPY, ePY);
        var w = Math.abs(ePX - sPX), h = Math.abs(ePY - sPY);
        var docSize = getDocSize();
        var docX = (x / docSize.width) * 100;
        var docY = (y / docSize.height) * 100;
        var docW = (w / docSize.width) * 100;
        var docH = (h / docSize.height) * 100;

        var anchor = pickAnchorForArea((sCX + eCX) / 2, (sCY + eCY) / 2, { x: x, y: y, w: w, h: h });
        if (anchor) {
            var rect = anchor.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
                var pl = rect.left + window.pageXOffset;
                var pt = rect.top + window.pageYOffset;
                return {
                    marker_type: 'area',
                    anchor_selector: encodeAnchor({
                        css: buildCssSelector(anchor), xpath: buildXPath(anchor),
                        fbX: docX, fbY: docY, fbW: docW, fbH: docH
                    }),
                    x_percent: ((x - pl) / rect.width) * 100,
                    y_percent: ((y - pt) / rect.height) * 100,
                    width_percent: (w / rect.width) * 100,
                    height_percent: (h / rect.height) * 100
                };
            }
        }
        return {
            marker_type: 'area',
            anchor_selector: encodeAnchor({ fbX: docX, fbY: docY, fbW: docW, fbH: docH }),
            x_percent: docX, y_percent: docY, width_percent: docW, height_percent: docH
        };
    }

    /* =========================================================
       Top BAR
       ========================================================= */
    function renderBar() {
        var oldBar = $('.vr-bar');
        if (oldBar) oldBar.remove();

        var bar = el('div', { class: 'vr-bar vr-bar--' + (IS_EDIT ? 'edit' : 'view') });

        bar.appendChild(el('div', { class: 'vr-bar__brand' }, [
            el('span', { class: 'vr-bar__logo' }, [
                el('span', { class: 'vr-bar__logo-dot' }),
                el('span', { class: 'vr-bar__logo-dot' }),
                el('span', { class: 'vr-bar__logo-dot' })
            ]),
            el('span', { class: 'vr-bar__name' }, 'Visual Review')
        ]));

        bar.appendChild(el('div', { class: 'vr-bar__divider' }));

        bar.appendChild(el('div', {
            class: 'vr-bar__mode vr-bar__mode--' + (IS_EDIT ? 'edit' : 'view')
        }, [
            el('span', { class: 'vr-bar__mode-dot' }),
            IS_EDIT ? I.edit_mode : I.view_mode
        ]));

        if (IS_EDIT) {
            bar.appendChild(el('div', { class: 'vr-bar__divider' }));
            bar.appendChild(el('button', {
                class: 'vr-bar__btn' + (state.placing === 'pin' ? ' vr-bar__btn--active' : ''),
                onclick: function () { togglePlacing('pin'); },
                title: I.add_pin
            }, [
                el('span', { class: 'vr-bar__icon', html: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5a2.5 2.5 0 0 1 0-5 2.5 2.5 0 0 1 0 5z"/></svg>' }),
                el('span', { class: 'vr-bar__btn-label' }, I.add_pin)
            ]));
            bar.appendChild(el('button', {
                class: 'vr-bar__btn' + (state.placing === 'area' ? ' vr-bar__btn--active' : ''),
                onclick: function () { togglePlacing('area'); },
                title: I.add_area
            }, [
                el('span', { class: 'vr-bar__icon', html: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="4" y="6" width="16" height="12" rx="1.5" stroke-dasharray="3 2"/></svg>' }),
                el('span', { class: 'vr-bar__btn-label' }, I.add_area)
            ]));
            bar.appendChild(el('button', {
                class: 'vr-bar__btn',
                onclick: function () { startGeneralFeedback(); },
                title: I.add_general
            }, [
                el('span', { class: 'vr-bar__icon', html: '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>' }),
                el('span', { class: 'vr-bar__btn-label' }, I.add_general)
            ]));
        }

        bar.appendChild(el('div', { class: 'vr-bar__divider' }));

        // Viewport switcher (desktop/tablet/mobile) — available in both modes
        bar.appendChild(renderViewportSwitcher());

        bar.appendChild(el('div', { class: 'vr-bar__divider' }));

        bar.appendChild(el('button', {
            class: 'vr-bar__btn vr-bar__btn--list',
            onclick: openListPanel,
            title: DATA.lang === 'nl' ? 'Lijst openen' : 'Open list'
        }, [
            el('span', { class: 'vr-bar__icon', html: '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor"><rect x="3" y="5" width="18" height="2" rx="1"/><rect x="3" y="11" width="18" height="2" rx="1"/><rect x="3" y="17" width="18" height="2" rx="1"/></svg>' }),
            el('span', { class: 'vr-bar__count', id: 'vr-count' }, '0')
        ]));

        document.body.appendChild(bar);
    }

    function renderViewportSwitcher() {
        var wrap = el('div', { class: 'vr-bar__viewports' });
        var current = DATA.viewport || 'desktop';

        var defs = [
            { key: 'desktop', label: I.viewport_desktop || 'Desktop',
              icon: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="13" rx="2"/><path d="M8 21h8M12 18v3"/></svg>' },
            { key: 'tablet', label: I.viewport_tablet || 'Tablet',
              icon: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M11 18h2"/></svg>' },
            { key: 'mobile', label: I.viewport_mobile || 'Mobile',
              icon: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="7" y="3" width="10" height="18" rx="2"/><path d="M10 18h4"/></svg>' }
        ];

        defs.forEach(function (def) {
            wrap.appendChild(el('button', {
                type: 'button',
                class: 'vr-bar__vbtn' + (current === def.key ? ' is-active' : ''),
                onclick: function () {
                    if (current === def.key) return;
                    navigateViewport(def.key);
                },
                title: def.label
            }, [
                el('span', { class: 'vr-bar__icon', html: def.icon })
            ]));
        });

        return wrap;
    }

    function navigateViewport(viewport) {
        // Build target URL with new viewport param
        var u;
        try {
            // If we're inside the iframe, we need to navigate the PARENT
            var target = (DATA.inFrame && window.parent && window.parent !== window)
                ? window.parent.location.href
                : window.location.href;
            u = new URL(target);
        } catch (e) {
            // Cross-origin block on parent — fall back to current window
            u = new URL(window.location.href);
        }
        if (viewport === 'desktop') {
            u.searchParams.delete('vr_view');
        } else {
            u.searchParams.set('vr_view', viewport);
        }
        u.searchParams.delete('vr_inframe');

        try {
            if (DATA.inFrame && window.parent && window.parent !== window) {
                window.parent.location.href = u.toString();
                return;
            }
        } catch (e) {}
        window.location.href = u.toString();
    }

    function updateCount() {
        var c = $('#vr-count');
        if (c) c.textContent = state.reviews.length;
    }

    /* =========================================================
       MARKERS
       ========================================================= */
    function clearAnchorObservers() {
        Object.keys(state.anchorMap).forEach(function (id) {
            var entry = state.anchorMap[id];
            if (entry && entry.observer) {
                try { entry.observer.disconnect(); } catch (e) {}
            }
        });
        state.anchorMap = {};
    }

    var pendingRender;
    function scheduleRender() {
        cancelAnimationFrame(pendingRender);
        pendingRender = requestAnimationFrame(renderMarkers);
    }

    function renderMarkers() {
        document.querySelectorAll('.vr-marker').forEach(function (m) { m.remove(); });
        clearAnchorObservers();

        state.reviews.forEach(function (r, idx) {
            var num = idx + 1;

            // General feedback has no page location — skip marker rendering.
            // It still appears in the side-panel list.
            if (r.marker_type === 'general') return;

            // Only render markers belonging to the current viewport.
            // Reviews from other viewports stay in the list but are hidden
            // from the page until user switches viewport.
            var reviewVp = r.viewport || 'desktop';
            if (reviewVp !== DATA.viewport) return;

            var pos = resolveReviewPosition(r);
            var marker;

            var classes = 'vr-marker';
            classes += r.marker_type === 'area' ? ' vr-marker--area' : ' vr-marker--pin';
            if (r.status === 'resolved') classes += ' vr-marker--resolved';
            if (state.selectedId === r.id) classes += ' vr-marker--active';
            if (!pos.anchored) classes += ' vr-marker--unanchored';

            if (r.marker_type === 'area' && pos.width != null && pos.height != null) {
                marker = el('div', {
                    class: classes,
                    style: {
                        left: pos.x + 'px', top: pos.y + 'px',
                        width: pos.width + 'px', height: pos.height + 'px'
                    },
                    onclick: function (e) { e.stopPropagation(); openReview(r.id); }
                }, [
                    el('span', { class: 'vr-marker__num' }, String(num))
                ]);
            } else {
                marker = el('div', {
                    class: classes,
                    style: { left: pos.x + 'px', top: pos.y + 'px' },
                    onclick: function (e) { e.stopPropagation(); openReview(r.id); }
                }, [
                    el('div', { class: 'vr-marker__pin' }, [el('span', {}, String(num))])
                ]);
            }
            document.body.appendChild(marker);

            if (pos.anchor && typeof ResizeObserver !== 'undefined') {
                try {
                    var ro = new ResizeObserver(scheduleRender);
                    ro.observe(pos.anchor);
                    state.anchorMap[r.id] = { el: pos.anchor, observer: ro };
                } catch (e) {}
            }
        });
    }

    window.addEventListener('resize', scheduleRender);
    window.addEventListener('load', scheduleRender);
    setTimeout(scheduleRender, 600);
    setTimeout(scheduleRender, 1800);
    if (typeof ResizeObserver !== 'undefined') {
        try { new ResizeObserver(scheduleRender).observe(document.body); } catch (e) {}
    }
    if (typeof MutationObserver !== 'undefined') {
        var mo = new MutationObserver(function (muts) {
            // ignore mutations inside our own UI
            for (var i = 0; i < muts.length; i++) {
                if (!isOurOwnElement(muts[i].target)) { scheduleRender(); return; }
            }
        });
        mo.observe(document.body, { childList: true, subtree: true });
    }

    /* =========================================================
       Placement
       ========================================================= */
    var overlayEl, hintEl;
    function togglePlacing(mode) {
        if (state.placing === mode) { cancelPlacing(); return; }
        state.placing = mode;
        renderBar();
        showPlacementOverlay();
        showHint(mode === 'pin' ? I.placing_pin : I.placing_area);
    }
    function cancelPlacing() {
        state.placing = null;
        hidePlacementOverlay();
        hideHint();
        renderBar();
    }
    function showPlacementOverlay() {
        hidePlacementOverlay();
        overlayEl = el('div', {
            class: 'vr-placement vr-placement--' + state.placing,
            onclick: function (e) {
                if (state.placing !== 'pin') return;
                handlePinPlacement(e);
            },
            onmousedown: function (e) {
                if (state.placing !== 'area') return;
                handleAreaStart(e);
            }
        });
        document.body.appendChild(overlayEl);
        document.addEventListener('keydown', escListener);
    }
    function hidePlacementOverlay() {
        if (overlayEl) { overlayEl.remove(); overlayEl = null; }
        document.removeEventListener('keydown', escListener);
    }
    function escListener(e) { if (e.key === 'Escape') cancelPlacing(); }

    function showHint(txt) {
        hideHint();
        hintEl = el('div', { class: 'vr-hint' }, [
            txt,
            el('span', { class: 'vr-hint__esc' }, 'ESC')
        ]);
        document.body.appendChild(hintEl);
    }
    function hideHint() { if (hintEl) { hintEl.remove(); hintEl = null; } }

    function handlePinPlacement(e) {
        var cx = e.clientX, cy = e.clientY;
        hidePlacementOverlay();
        var payload = buildPinPayload(cx, cy);
        cancelPlacing();
        startDraft(payload);
    }
    function handleAreaStart(e) {
        e.preventDefault();
        var sCX = e.clientX, sCY = e.clientY;
        var sPX = sCX + window.pageXOffset, sPY = sCY + window.pageYOffset;

        var rect = el('div', { class: 'vr-placement-rect' });
        rect.style.left = sPX + 'px'; rect.style.top = sPY + 'px';
        document.body.appendChild(rect);

        function onMove(ev) {
            var cx = ev.clientX + window.pageXOffset, cy = ev.clientY + window.pageYOffset;
            var x = Math.min(sPX, cx), y = Math.min(sPY, cy);
            rect.style.left = x + 'px'; rect.style.top = y + 'px';
            rect.style.width = Math.abs(cx - sPX) + 'px';
            rect.style.height = Math.abs(cy - sPY) + 'px';
        }
        function onUp(ev) {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onUp);
            var eCX = ev.clientX, eCY = ev.clientY;
            var w = Math.abs((eCX + window.pageXOffset) - sPX);
            var h = Math.abs((eCY + window.pageYOffset) - sPY);
            rect.remove();
            hidePlacementOverlay();
            if (w < 12 || h < 12) {
                cancelPlacing();
                showToast(DATA.lang === 'nl' ? 'Gebied te klein' : 'Area too small');
                return;
            }
            var payload = buildAreaPayload(sCX, sCY, eCX, eCY);
            cancelPlacing();
            startDraft(payload);
        }
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }

    /* =========================================================
       SIDE PANEL
       ========================================================= */
    var panelEl;
    function ensurePanel() {
        if (panelEl) return panelEl;
        panelEl = el('div', { class: 'vr-panel' });
        document.body.appendChild(panelEl);
        return panelEl;
    }
    function openPanel(content) {
        ensurePanel().innerHTML = '';
        (Array.isArray(content) ? content : [content]).forEach(function (c) { panelEl.appendChild(c); });
        requestAnimationFrame(function () { panelEl.classList.add('vr-panel--open'); });
    }
    function closePanel() {
        if (!panelEl) return;
        panelEl.classList.remove('vr-panel--open');
        state.selectedId = null;
        renderMarkers();
    }

    function startGeneralFeedback() {
        // Cancel any placement mode that might be active
        if (state.placing) cancelPlacing();
        startDraft({
            marker_type: 'general',
            // x/y default to 0 — meaningless for general but DB needs them
            x_percent: 0,
            y_percent: 0
        });
    }

    function startDraft(partial) {
        state.selectedId = null;
        var noteInput, nameInput;
        var isGeneral = partial.marker_type === 'general';

        var draftTypeLabel;
        if (isGeneral) {
            draftTypeLabel = I.add_general;
        } else if (partial.marker_type === 'area') {
            draftTypeLabel = I.add_area;
        } else {
            draftTypeLabel = I.add_pin;
        }

        var head = el('div', { class: 'vr-panel__head' }, [
            el('h3', { class: 'vr-panel__title' }, [
                el('span', { class: 'vr-panel__num vr-panel__num--new' }, DATA.lang === 'nl' ? 'NIEUW' : 'NEW'),
                draftTypeLabel
            ]),
            el('button', { class: 'vr-panel__close', onclick: closePanel, 'aria-label': 'Close' }, '×')
        ]);

        var saveBtn;
        var bodyChildren = [
            el('div', { class: 'vr-panel__lang-pill' },
                DATA.lang === 'nl' ? 'NL · Nederlands' : 'EN · English')
        ];

        if (isGeneral) {
            bodyChildren.push(
                el('div', { class: 'vr-panel__general-note' },
                    DATA.lang === 'nl'
                        ? 'Site-brede feedback. Niet gekoppeld aan een specifieke pagina.'
                        : 'Site-wide feedback. Not tied to a specific page.')
            );
        }

        bodyChildren.push(
            el('div', { class: 'vr-field' }, [
                el('label', { class: 'vr-field__label' }, DATA.lang === 'nl' ? 'Opmerking' : 'Comment'),
                noteInput = el('textarea', {
                    placeholder: isGeneral
                        ? (DATA.lang === 'nl' ? 'Wat zou je site-breed willen veranderen?' : 'What would you change site-wide?')
                        : I.placeholder_note,
                    rows: 8
                })
            ]),
            el('div', { class: 'vr-field' }, [
                el('label', { class: 'vr-field__label' }, DATA.lang === 'nl' ? 'Naam' : 'Name'),
                nameInput = el('input', {
                    type: 'text',
                    placeholder: I.placeholder_name,
                    value: getStoredName()
                })
            ]),
            el('div', { class: 'vr-panel__actions' }, [
                saveBtn = el('button', {
                    class: 'vr-pbtn vr-pbtn--primary',
                    type: 'button',
                    onclick: function () {
                        if (saveBtn.disabled) return; // double-click guard
                        if (!noteInput.value.trim()) { noteInput.focus(); return; }

                        // Disable button + show loading state
                        saveBtn.disabled = true;
                        saveBtn.dataset.originalText = saveBtn.textContent;
                        saveBtn.textContent = DATA.lang === 'nl' ? 'Opslaan...' : 'Saving...';
                        saveBtn.classList.add('vr-pbtn--loading');

                        var name = nameInput.value.trim();

                        // For general: page_path becomes '*' so it's site-wide.
                        var payload = Object.assign({
                            page_url:       isGeneral ? DATA.pageUrl : DATA.pageUrl,
                            page_path:      isGeneral ? '*' : DATA.pagePath,
                            viewport:       DATA.viewport || 'desktop',
                            note:           noteInput.value.trim(),
                            author_name:    name,
                            viewport_width: window.innerWidth
                        }, partial);

                        createReview(payload).then(function (r) {
                            // Persist name for next time
                            if (name) setStoredName(name);

                            // Only add to local state if it belongs on this page
                            // (general items don't render as markers but we keep them
                            // in state so the list/count is accurate per page-view scope)
                            state.reviews.push(r);
                            renderMarkers(); updateCount(); closePanel();
                            showToast(DATA.lang === 'nl' ? 'Opgeslagen ✓' : 'Saved ✓');
                        }).catch(function (err) {
                            // Re-enable on error so user can retry
                            saveBtn.disabled = false;
                            saveBtn.textContent = saveBtn.dataset.originalText;
                            saveBtn.classList.remove('vr-pbtn--loading');
                            console.warn('[VR] save failed', err);
                            showToast(DATA.lang === 'nl' ? 'Opslaan mislukt — probeer opnieuw' : 'Save failed — try again');
                        });
                    }
                }, I.save),
                el('button', { class: 'vr-pbtn vr-pbtn--ghost', type: 'button', onclick: closePanel }, I.cancel)
            ])
        );

        var body = el('div', { class: 'vr-panel__body' }, bodyChildren);
        openPanel([head, body]);
        setTimeout(function () { noteInput.focus(); }, 200);

        // Ctrl+Enter (or Cmd+Enter) submits — common UX pattern
        noteInput.addEventListener('keydown', function (e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                saveBtn.click();
            }
        });
        nameInput.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                saveBtn.click();
            }
        });
    }

    function openReview(id) {
        var r = state.reviews.find(function (x) { return x.id === id; });
        if (!r) return;
        state.selectedId = id;
        renderMarkers();

        var idx = state.reviews.indexOf(r) + 1;
        var noteRaw = (DATA.lang === 'en') ? r.note_en : r.note_nl;
        var hasContent = noteRaw && noteRaw.trim();

        var typeLabel;
        if (r.marker_type === 'general') {
            typeLabel = '🌐 ' + I.add_general;
        } else if (r.marker_type === 'area') {
            typeLabel = I.add_area;
        } else {
            typeLabel = I.add_pin;
        }

        var head = el('div', { class: 'vr-panel__head' }, [
            el('h3', { class: 'vr-panel__title' }, [
                el('span', { class: 'vr-panel__num' }, '#' + idx),
                typeLabel
            ]),
            el('button', { class: 'vr-panel__close', onclick: closePanel, 'aria-label': 'Close' }, '×')
        ]);

        var meta = el('div', { class: 'vr-panel__meta' }, [
            el('span', { class: 'vr-panel__status vr-panel__status--' + r.status },
               r.status === 'open' ? I.open : I.resolved),
            r.author_name ? el('span', { class: 'vr-panel__meta-item' }, r.author_name) : null,
            el('span', { class: 'vr-panel__meta-item' }, r.lang.toUpperCase())
        ]);
        var bodyChildren = [meta];

        if (IS_EDIT) {
            var noteInput = el('textarea', {
                placeholder: I.placeholder_note, rows: 8, text: noteRaw || ''
            });
            bodyChildren.push(el('div', { class: 'vr-field' }, [
                el('label', { class: 'vr-field__label' },
                    (DATA.lang === 'nl' ? 'Opmerking' : 'Comment') + ' (' + DATA.lang.toUpperCase() + ')'),
                noteInput
            ]));
            bodyChildren.push(el('div', { class: 'vr-panel__actions' }, [
                el('button', { class: 'vr-pbtn vr-pbtn--primary',
                    onclick: function () {
                        updateReview(r.id, { note: noteInput.value }).then(function (u) {
                            Object.assign(r, u);
                            showToast(DATA.lang === 'nl' ? 'Opgeslagen ✓' : 'Saved ✓');
                        });
                    }
                }, I.save),
                el('button', { class: 'vr-pbtn',
                    onclick: function () {
                        var ns = r.status === 'open' ? 'resolved' : 'open';
                        updateReview(r.id, { status: ns }).then(function (u) {
                            Object.assign(r, u); renderMarkers(); openReview(r.id);
                        });
                    }
                }, r.status === 'open' ? I.resolve : I.reopen),
                el('button', { class: 'vr-pbtn vr-pbtn--danger',
                    onclick: function () {
                        if (!confirm(I.confirm_delete)) return;
                        deleteReviewApi(r.id).then(function () {
                            state.reviews = state.reviews.filter(function (x) { return x.id !== r.id; });
                            renderMarkers(); updateCount(); closePanel();
                        });
                    }
                }, I.delete)
            ]));
        } else {
            if (hasContent) {
                bodyChildren.push(el('div', { class: 'vr-field' }, [
                    el('label', { class: 'vr-field__label' }, DATA.lang === 'nl' ? 'Opmerking' : 'Comment'),
                    el('div', { class: 'vr-readonly-text', html: '<p>' + escHtml(noteRaw).replace(/\n/g, '<br>') + '</p>' })
                ]));
            } else {
                bodyChildren.push(el('div', { class: 'vr-translation-pending' }, I.translation_pending));
            }
        }

        openPanel([head, el('div', { class: 'vr-panel__body' }, bodyChildren)]);
    }

    function openListPanel() {
        state.selectedId = null;
        renderMarkers();

        var head = el('div', { class: 'vr-panel__head' }, [
            el('h3', { class: 'vr-panel__title' }, [
                el('span', { class: 'vr-panel__num' }, String(state.reviews.length)),
                DATA.lang === 'nl' ? 'Alle opmerkingen' : 'All comments'
            ]),
            el('button', { class: 'vr-panel__close', onclick: closePanel, 'aria-label': 'Close' }, '×')
        ]);

        var listEl;
        if (state.reviews.length === 0) {
            listEl = el('div', { class: 'vr-list__empty' }, I.no_reviews);
        } else {
            listEl = el('div', { class: 'vr-list' });
            state.reviews.forEach(function (r, idx) {
                var note = DATA.lang === 'en' ? r.note_en : r.note_nl;
                var preview = (note && note.trim()) ? note : I.translation_pending;
                var typeLabel;
                if (r.marker_type === 'general') {
                    typeLabel = '🌐 ' + (DATA.lang === 'nl' ? 'Algemeen' : 'General');
                } else if (r.marker_type === 'area') {
                    typeLabel = '▭ ' + (DATA.lang === 'nl' ? 'Gebied' : 'Area');
                } else {
                    typeLabel = '◉ Pin';
                }

                listEl.appendChild(el('div', {
                    class: 'vr-list__item' +
                        (r.status === 'resolved' ? ' vr-list__item--resolved' : '') +
                        (r.marker_type === 'general' ? ' vr-list__item--general' : ''),
                    onclick: function () {
                        openReview(r.id);
                        // General feedback has no location — don't scroll
                        if (r.marker_type !== 'general') {
                            var pos = resolveReviewPosition(r);
                            window.scrollTo({ top: pos.y - window.innerHeight / 3, behavior: 'smooth' });
                        }
                    }
                }, [
                    el('div', { class: 'vr-list__num' }, String(idx + 1)),
                    el('div', { class: 'vr-list__body' }, [
                        el('p', { class: 'vr-list__txt', text: preview }),
                        el('div', { class: 'vr-list__meta' },
                            typeLabel +
                            ' · ' + (r.status === 'open' ? I.open : I.resolved) +
                            (r.author_name ? ' · ' + r.author_name : '')
                        )
                    ])
                ]));
            });
        }
        openPanel([head, el('div', { class: 'vr-panel__body' }, listEl)]);
    }

    /* =========================================================
       Toast
       ========================================================= */
    var toastTimer;
    function showToast(msg) {
        var t = $('.vr-toast');
        if (!t) { t = el('div', { class: 'vr-toast' }); document.body.appendChild(t); }
        t.textContent = msg;
        t.classList.add('vr-toast--show');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { t.classList.remove('vr-toast--show'); }, 1800);
    }

    /* =========================================================
       Link rewriting — keep review mode across navigation
       ---------------------------------------------------------
       When in review/edit mode, all internal links should
       preserve the vr_review/lang/vr_edit params so the user
       stays in the same mode when clicking through the site.
       ========================================================= */

    function shouldRewriteLink(a) {
        if (!a || !a.href) return false;
        if (a.dataset.vrSkip === '1') return false;
        if (isOurOwnElement(a)) return false;

        // Only http(s) links
        var href = a.getAttribute('href');
        if (!href) return false;
        if (href.startsWith('#')) return false;
        if (href.startsWith('mailto:') || href.startsWith('tel:') || href.startsWith('javascript:')) return false;

        // Same origin only
        try {
            var u = new URL(a.href, window.location.href);
            if (u.origin !== window.location.origin) return false;
            // Skip wp-admin and login URLs
            if (u.pathname.indexOf('/wp-admin') === 0) return false;
            if (u.pathname.indexOf('/wp-login') === 0) return false;
            return true;
        } catch (e) {
            return false;
        }
    }

    function rewriteLink(a) {
        try {
            var u = new URL(a.href, window.location.href);
            u.searchParams.set('vr_review', '1');
            u.searchParams.set('lang', DATA.lang);
            if (IS_EDIT && DATA.editCode) {
                u.searchParams.set('vr_edit', DATA.editCode);
            }
            // Preserve viewport mode across navigation
            if (DATA.viewport && DATA.viewport !== 'desktop') {
                u.searchParams.set('vr_view', DATA.viewport);
            }
            // If we're inside the iframe, keep navigation inside it
            if (DATA.inFrame) {
                u.searchParams.set('vr_inframe', '1');
            }
            a.href = u.toString();
            a.dataset.vrRewritten = '1';
        } catch (e) { /* ignore */ }
    }

    function rewriteAllLinks(root) {
        var links = (root || document).querySelectorAll('a[href]');
        for (var i = 0; i < links.length; i++) {
            var a = links[i];
            if (a.dataset.vrRewritten === '1') continue;
            if (shouldRewriteLink(a)) rewriteLink(a);
        }
    }

    function setupLinkRewriting() {
        rewriteAllLinks(document);

        // Re-run on DOM changes (lazy loaded content, AJAX nav, Elementor popups)
        if (typeof MutationObserver !== 'undefined') {
            var lro = new MutationObserver(function (muts) {
                for (var i = 0; i < muts.length; i++) {
                    var m = muts[i];
                    if (isOurOwnElement(m.target)) continue;
                    if (m.addedNodes && m.addedNodes.length) {
                        for (var j = 0; j < m.addedNodes.length; j++) {
                            var n = m.addedNodes[j];
                            if (n.nodeType !== 1) continue;
                            if (isOurOwnElement(n)) continue;
                            if (n.tagName === 'A' && shouldRewriteLink(n)) rewriteLink(n);
                            else if (n.querySelectorAll) rewriteAllLinks(n);
                        }
                    }
                }
            });
            lro.observe(document.body, { childList: true, subtree: true });
        }

        // Catch programmatic href changes / very late attribute mutations
        // by intercepting click events as a final safety net.
        document.addEventListener('click', function (e) {
            var a = e.target.closest && e.target.closest('a[href]');
            if (!a) return;
            if (a.dataset.vrRewritten === '1') return;
            if (!shouldRewriteLink(a)) return;
            rewriteLink(a);
        }, true); // capture phase so we run before the navigation
    }

    /* =========================================================
       Viewport / Device-frame shell
       ---------------------------------------------------------
       When ?vr_view=tablet|mobile is set (and we're NOT inside
       the iframe), we render a device-frame shell instead of
       the normal plugin UI. The shell hides the page contents
       and loads the same URL in an iframe with vr_inframe=1.
       Markers + bar live inside that iframe — except the
       device switcher bar, which lives in the parent so it's
       always available.
       ========================================================= */

    var VIEWPORT_SIZES = {
        desktop: { width: 0,    label: 'Desktop' }, // 0 = full width
        tablet:  { width: 820,  label: 'Tablet'  },
        mobile:  { width: 390,  label: 'Mobile'  }
    };

    function buildViewportUrl(viewport) {
        var u = new URL(window.location.href);
        if (!viewport || viewport === 'desktop') {
            u.searchParams.delete('vr_view');
        } else {
            u.searchParams.set('vr_view', viewport);
        }
        u.searchParams.delete('vr_inframe');
        return u.toString();
    }

    function buildInframeUrl() {
        var u = new URL(window.location.href);
        u.searchParams.set('vr_inframe', '1');
        return u.toString();
    }

    function renderShell() {
        // Lock the host page so its content doesn't show through.
        // We don't remove the body content (that'd break the WP load),
        // we just hide it under our shell which covers the viewport.
        document.documentElement.classList.add('vr-shell-host');

        var cfg = VIEWPORT_SIZES[DATA.viewport] || VIEWPORT_SIZES.desktop;

        var shell = el('div', { class: 'vr-shell', 'data-viewport': DATA.viewport });

        // Top status strip
        var statusStrip = el('div', { class: 'vr-shell__statusbar' }, [
            el('div', { class: 'vr-shell__brand' }, [
                el('span', { class: 'vr-shell__brand-logo' }, [
                    el('span', { class: 'vr-shell__brand-dot' }),
                    el('span', { class: 'vr-shell__brand-dot' }),
                    el('span', { class: 'vr-shell__brand-dot' })
                ]),
                el('span', {}, 'Visual Review · ' + cfg.label + ' (' + cfg.width + 'px)')
            ]),
            el('div', { class: 'vr-shell__viewport-switch' }, viewportSwitchButtons())
        ]);
        shell.appendChild(statusStrip);

        // Device frame holding the iframe
        var frame = el('div', { class: 'vr-shell__frame', style: { width: cfg.width + 'px' } });
        var iframe = el('iframe', {
            class: 'vr-shell__iframe',
            src: buildInframeUrl(),
            title: 'Site preview',
            allow: 'fullscreen'
        });
        frame.appendChild(iframe);
        shell.appendChild(frame);

        document.body.appendChild(shell);

        // Receive scroll-into-view requests from inside the iframe
        // (when user clicks a marker we want the iframe to scroll there)
        window.addEventListener('message', function (e) {
            if (!e || !e.data || e.data.type !== 'vr:shell-resize') return;
            // future hook
        });
    }

    function viewportSwitchButtons() {
        var buttons = [];
        Object.keys(VIEWPORT_SIZES).forEach(function (key) {
            var cfg = VIEWPORT_SIZES[key];
            var icon = key === 'mobile'
                ? '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="7" y="3" width="10" height="18" rx="2"/><path d="M10 18h4"/></svg>'
                : key === 'tablet'
                ? '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M11 18h2"/></svg>'
                : '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="5" width="20" height="13" rx="2"/><path d="M8 21h8M12 18v3"/></svg>';

            buttons.push(el('button', {
                type: 'button',
                class: 'vr-shell__vbtn' + (DATA.viewport === key ? ' is-active' : ''),
                onclick: function () {
                    if (DATA.viewport === key) return;
                    window.location.href = buildViewportUrl(key);
                },
                title: cfg.label
            }, [
                el('span', { class: 'vr-shell__vbtn-icon', html: icon }),
                el('span', { class: 'vr-shell__vbtn-label' }, cfg.label)
            ]));
        });
        return buttons;
    }

    /* =========================================================
       Inframe parent communication
       ---------------------------------------------------------
       When we're inside an iframe (vr_inframe=1), we may receive
       a "scroll to review" instruction from a parent that came
       from the admin overview. The parent sends:
         { type: 'vr:scroll-to-review', id: 123 }
       ========================================================= */
    function setupInframeMessaging() {
        if (!DATA.inFrame) return;
        window.addEventListener('message', function (e) {
            if (!e || !e.data) return;
            if (e.data.type === 'vr:scroll-to-review') {
                var target = state.reviews.find(function (r) { return r.id === e.data.id; });
                if (!target) return;
                if (target.marker_type === 'general') {
                    openReview(target.id);
                } else {
                    openReview(target.id);
                    var pos = resolveReviewPosition(target);
                    window.scrollTo({ top: pos.y - window.innerHeight / 3, behavior: 'smooth' });
                }
            }
        });
        // Tell parent we're ready, so it can send queued messages
        try {
            window.parent.postMessage({ type: 'vr:iframe-ready' }, '*');
        } catch (e) {}
    }

    /* =========================================================
       Boot
       ========================================================= */
    function boot() {
        if (DATA.shellMode) {
            // Shell parent: just render device frame + iframe + viewport switcher
            renderShell();
            return;
        }
        // Normal page (either desktop, or inside the iframe)
        renderBar();
        setupLinkRewriting();
        setupInframeMessaging();
        loadReviews().catch(function (err) { console.warn('[VR] load failed', err); });
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot);
    } else {
        boot();
    }
})();
