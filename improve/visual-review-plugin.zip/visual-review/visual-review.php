<?php
/**
 * Plugin Name: Visual Review
 * Plugin URI: https://onlineheroes.agency
 * Description: Visuele review tool voor WordPress. Plaats pins of gebieden op je site en verzamel feedback in NL en EN.
 * Version: 1.5.0
 * Author: Online Heroes
 * Author URI: https://onlineheroes.agency
 * Text Domain: visual-review
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'VR_VERSION', '1.5.0' );
define( 'VR_PLUGIN_FILE', __FILE__ );
define( 'VR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'VR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'VR_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

require_once VR_PLUGIN_DIR . 'includes/class-vr-database.php';
require_once VR_PLUGIN_DIR . 'includes/class-vr-settings.php';
require_once VR_PLUGIN_DIR . 'includes/class-vr-translator.php';
require_once VR_PLUGIN_DIR . 'includes/class-vr-rest.php';
require_once VR_PLUGIN_DIR . 'includes/class-vr-frontend.php';
require_once VR_PLUGIN_DIR . 'admin/class-vr-admin.php';

register_activation_hook( __FILE__, array( 'VR_Database', 'install' ) );
register_deactivation_hook( __FILE__, array( 'VR_Database', 'deactivate' ) );

add_action( 'plugins_loaded', 'vr_init' );
function vr_init() {
    load_plugin_textdomain( 'visual-review', false, dirname( VR_PLUGIN_BASENAME ) . '/languages' );

    // Auto-upgrade DB schema when plugin version changes
    if ( get_option( 'vr_db_version' ) !== VR_Database::DB_VERSION ) {
        VR_Database::install();
    }

    new VR_Admin();
    new VR_REST();
    new VR_Frontend();
}
