<?php
/**
 * Visual Review uninstall handler.
 * Wordt alleen aangeroepen wanneer plugin via WP UI verwijderd wordt.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Settings weghalen
delete_option( 'vr_settings' );
delete_option( 'vr_db_version' );

// Tabel droppen — bewust: full uninstall = alle data weg
$table = $wpdb->prefix . 'vr_reviews';
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
