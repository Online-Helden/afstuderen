<?php
/**
 * Database handler voor Visual Review.
 *
 * Tabel structuur:
 * - id, page_url, anchor data (selector + percentages), marker_type (pin|area)
 * - note_nl + note_en als aparte kolommen voor toekomstige vertaling
 * - author_name, status, timestamps
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VR_Database {

    const TABLE_NAME = 'vr_reviews';
    const DB_VERSION = '1.1.0';

    public static function table_name() {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_NAME;
    }

    public static function install() {
        global $wpdb;

        $table   = self::table_name();
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE {$table} (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            page_url VARCHAR(500) NOT NULL,
            page_path VARCHAR(500) NOT NULL,
            marker_type VARCHAR(20) NOT NULL DEFAULT 'pin',
            viewport VARCHAR(20) NOT NULL DEFAULT 'desktop',
            anchor_selector TEXT NULL,
            x_percent DECIMAL(7,4) NOT NULL,
            y_percent DECIMAL(7,4) NOT NULL,
            width_percent DECIMAL(7,4) NULL,
            height_percent DECIMAL(7,4) NULL,
            viewport_width INT NULL,
            note_nl LONGTEXT NULL,
            note_en LONGTEXT NULL,
            author_name VARCHAR(190) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'open',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY page_path (page_path(191)),
            KEY status (status),
            KEY viewport (viewport)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        update_option( 'vr_db_version', self::DB_VERSION );

        // Defaults
        if ( false === get_option( 'vr_settings' ) ) {
            add_option( 'vr_settings', array(
                'enabled'    => false,
                'edit_code'  => self::generate_code(),
            ) );
        }
    }

    public static function deactivate() {
        // Bewust geen drop — data blijft bewaard.
    }

    public static function generate_code( $length = 12 ) {
        $chars  = 'abcdefghijkmnpqrstuvwxyz23456789'; // zonder verwarrende tekens
        $code   = '';
        for ( $i = 0; $i < $length; $i++ ) {
            $code .= $chars[ random_int( 0, strlen( $chars ) - 1 ) ];
        }
        return $code;
    }

    /**
     * Haal alle reviews op voor een bepaalde page_path.
     * Inclusief site-brede (general) feedback opgeslagen onder page_path = '*'.
     */
    public static function get_for_path( $path ) {
        global $wpdb;
        $table = self::table_name();
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table}
                 WHERE page_path = %s OR page_path = '*'
                 ORDER BY (page_path = '*') DESC, created_at ASC",
                $path
            )
        );
    }

    public static function get_all( $args = array() ) {
        global $wpdb;
        $table = self::table_name();

        $where  = '1=1';
        $params = array();

        if ( ! empty( $args['status'] ) ) {
            $where   .= ' AND status = %s';
            $params[] = $args['status'];
        }

        $sql = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC";
        if ( ! empty( $params ) ) {
            $sql = $wpdb->prepare( $sql, $params );
        }
        return $wpdb->get_results( $sql );
    }

    public static function get( $id ) {
        global $wpdb;
        $table = self::table_name();
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
    }

    public static function insert( $data ) {
        global $wpdb;
        $table = self::table_name();
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function update( $id, $data ) {
        global $wpdb;
        $table = self::table_name();
        return $wpdb->update( $table, $data, array( 'id' => $id ) );
    }

    public static function delete( $id ) {
        global $wpdb;
        $table = self::table_name();
        return $wpdb->delete( $table, array( 'id' => $id ) );
    }
}
