<?php
/**
 * Translator voor Visual Review.
 *
 * Communiceert met een lokaal AI model via een OpenAI-compatible
 * chat completions endpoint. Vertaalt NL → EN en slaat het resultaat
 * op in de note_en kolom van de review.
 *
 * Lock: voorkomt dat meerdere vertalingen tegelijk lopen om het
 * lokale model niet te overbelasten.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VR_Translator {

    const LOCK_KEY      = 'vr_translate_lock';
    const LOCK_TIMEOUT  = 120; // seconden — vangnet als een request hangt
    const HTTP_TIMEOUT  = 90;  // seconden voor de HTTP request zelf

    /**
     * Probeer een lock te zetten. Returns true als gelukt, false als
     * er al een vertaling loopt.
     */
    public static function acquire_lock() {
        if ( get_transient( self::LOCK_KEY ) ) {
            return false;
        }
        set_transient( self::LOCK_KEY, time(), self::LOCK_TIMEOUT );
        return true;
    }

    public static function release_lock() {
        delete_transient( self::LOCK_KEY );
    }

    public static function is_locked() {
        return (bool) get_transient( self::LOCK_KEY );
    }

    /**
     * Vertaal één review van NL naar EN.
     *
     * @param int $review_id
     * @return array { success: bool, message: string, translation?: string }
     */
    public static function translate_review( $review_id ) {
        $review = VR_Database::get( $review_id );
        if ( ! $review ) {
            return array( 'success' => false, 'message' => 'Review niet gevonden.' );
        }

        $source = trim( (string) $review->note_nl );
        if ( $source === '' ) {
            return array( 'success' => false, 'message' => 'Geen Nederlandse tekst om te vertalen.' );
        }

        $result = self::call_ai( $source );

        if ( ! $result['success'] ) {
            return $result;
        }

        VR_Database::update( $review_id, array( 'note_en' => $result['translation'] ) );

        return $result;
    }

    /**
     * Doe de daadwerkelijke API-call naar het lokale model.
     */
    private static function call_ai( $dutch_text ) {
        $endpoint = VR_Settings::get( 'ai_endpoint' );
        $model    = VR_Settings::get( 'ai_model' );
        $prompt   = VR_Settings::get( 'ai_prompt' );

        if ( empty( $endpoint ) ) {
            return array( 'success' => false, 'message' => 'Geen AI endpoint geconfigureerd.' );
        }

        $body = array(
            'model'    => $model ?: 'local-model',
            'messages' => array(
                array( 'role' => 'system', 'content' => $prompt ),
                array( 'role' => 'user',   'content' => $dutch_text ),
            ),
            'temperature' => 0.2,
            'max_tokens'  => 600,
            // Sommige llama.cpp builds ondersteunen dit niet maar negeren het netjes
            'response_format' => array( 'type' => 'json_object' ),
        );

        $response = wp_remote_post( $endpoint, array(
            'timeout' => self::HTTP_TIMEOUT,
            'headers' => array(
                'Content-Type'      => 'application/json',
                'ngrok-skip-browser-warning' => 'true', // voor ngrok free
            ),
            'body'    => wp_json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) {
            return array(
                'success' => false,
                'message' => 'Verbinding mislukt: ' . $response->get_error_message(),
            );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $raw  = wp_remote_retrieve_body( $response );

        if ( $code < 200 || $code >= 300 ) {
            return array(
                'success' => false,
                'message' => 'AI endpoint gaf HTTP ' . $code . ': ' . substr( $raw, 0, 200 ),
            );
        }

        $parsed = json_decode( $raw, true );
        if ( ! is_array( $parsed ) ) {
            return array( 'success' => false, 'message' => 'Ongeldige JSON van endpoint.' );
        }

        $content = isset( $parsed['choices'][0]['message']['content'] )
            ? $parsed['choices'][0]['message']['content']
            : '';

        if ( $content === '' ) {
            return array( 'success' => false, 'message' => 'Lege response van model.' );
        }

        $translation = self::extract_translation( $content );

        if ( $translation === null || $translation === '' ) {
            return array(
                'success' => false,
                'message' => 'Kon vertaling niet uit response halen: ' . substr( $content, 0, 200 ),
            );
        }

        return array(
            'success'     => true,
            'message'     => 'Vertaald.',
            'translation' => $translation,
        );
    }

    /**
     * Trek de daadwerkelijke vertaling uit de model output.
     * Verwacht JSON {"translation": "..."} maar valt terug op
     * de ruwe tekst als JSON parsing faalt — lokale modellen
     * hallucineren soms extra tekens om de JSON heen.
     */
    private static function extract_translation( $content ) {
        $content = trim( $content );

        // Strip markdown code fences als die er omheen staan
        $content = preg_replace( '/^```(?:json)?\s*/i', '', $content );
        $content = preg_replace( '/\s*```$/', '', $content );
        $content = trim( $content );

        // Probeer JSON te parsen
        $data = json_decode( $content, true );
        if ( is_array( $data ) && isset( $data['translation'] ) ) {
            return trim( (string) $data['translation'] );
        }

        // Fallback: zoek met regex naar "translation": "..."
        if ( preg_match( '/"translation"\s*:\s*"((?:[^"\\\\]|\\\\.)*)"/s', $content, $m ) ) {
            return stripcslashes( $m[1] );
        }

        // Laatste redmiddel: als het hele ding lijkt op gewone tekst zonder JSON,
        // gebruik dat. Veilig want we hebben de NL bron al apart staan.
        if ( $content !== '' && strlen( $content ) < 2000 && strpos( $content, '{' ) === false ) {
            return $content;
        }

        return null;
    }
}
