<?php
/**
 * Frontend loader. Detecteert ?vr_review=1 + lang en laadt de juiste assets.
 *
 * Modes:
 *  - ?vr_review=1                 -> view mode (open voor iedereen als plugin enabled)
 *  - ?vr_review=1&vr_edit=CODE    -> edit mode (vereist matching code)
 *  - ?lang=nl|en                  -> taal (default nl)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VR_Frontend {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', array( $this, 'maybe_enqueue' ) );
        add_action( 'wp_footer', array( $this, 'maybe_render_root' ) );
    }

    public function is_review_request() {
        return ! empty( $_GET['vr_review'] );
    }

    public function get_lang() {
        $lang = isset( $_GET['lang'] ) ? strtolower( sanitize_text_field( wp_unslash( $_GET['lang'] ) ) ) : 'nl';
        return in_array( $lang, array( 'nl', 'en' ), true ) ? $lang : 'nl';
    }

    public function get_viewport() {
        $vp = isset( $_GET['vr_view'] ) ? strtolower( sanitize_text_field( wp_unslash( $_GET['vr_view'] ) ) ) : 'desktop';
        return in_array( $vp, array( 'desktop', 'tablet', 'mobile' ), true ) ? $vp : 'desktop';
    }

    /**
     * Are we rendering the outer "shell" (with device frame + iframe) or the
     * inner page (which lives inside the iframe in non-desktop modes)?
     *
     * Shell rules:
     *   - viewport != desktop
     *   - AND vr_inframe is NOT set (we're the outer page, not the iframe content)
     */
    public function is_shell_mode() {
        if ( ! empty( $_GET['vr_inframe'] ) ) {
            return false; // we're inside the iframe, render normally
        }
        return $this->get_viewport() !== 'desktop';
    }

    public function is_edit_mode() {
        if ( empty( $_GET['vr_edit'] ) ) {
            return false;
        }
        $supplied = sanitize_text_field( wp_unslash( $_GET['vr_edit'] ) );
        $expected = VR_Settings::get_edit_code();
        return ! empty( $expected ) && hash_equals( $expected, $supplied );
    }

    public function maybe_enqueue() {
        if ( is_admin() || ! VR_Settings::is_enabled() || ! $this->is_review_request() ) {
            return;
        }

        wp_enqueue_style(
            'vr-frontend',
            VR_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            VR_VERSION
        );

        wp_enqueue_script(
            'vr-frontend',
            VR_PLUGIN_URL . 'assets/js/frontend.js',
            array(),
            VR_VERSION,
            true
        );

        $lang     = $this->get_lang();
        $edit     = $this->is_edit_mode();
        $viewport = $this->get_viewport();
        $shell    = $this->is_shell_mode();

        wp_localize_script( 'vr-frontend', 'VR_DATA', array(
            'restUrl'   => esc_url_raw( rest_url( 'visual-review/v1' ) ),
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'lang'      => $lang,
            'editMode'  => $edit,
            'editCode'  => $edit ? VR_Settings::get_edit_code() : '',
            'pageUrl'   => home_url( add_query_arg( null, null ) ),
            'pagePath'  => $this->current_path(),
            'viewport'  => $viewport,
            'shellMode' => $shell,
            'inFrame'   => ! empty( $_GET['vr_inframe'] ),
            'i18n'      => $this->i18n( $lang ),
        ) );
    }

    public function maybe_render_root() {
        if ( is_admin() || ! VR_Settings::is_enabled() || ! $this->is_review_request() ) {
            return;
        }

        $mode     = $this->is_edit_mode() ? 'edit' : 'view';
        $viewport = $this->get_viewport();
        $shell    = $this->is_shell_mode() ? '1' : '0';
        $inframe  = ! empty( $_GET['vr_inframe'] ) ? '1' : '0';

        echo '<div id="vr-root" data-mode="' . esc_attr( $mode )
            . '" data-viewport="' . esc_attr( $viewport )
            . '" data-shell="' . esc_attr( $shell )
            . '" data-inframe="' . esc_attr( $inframe )
            . '"></div>';
    }

    private function current_path() {
        $path = wp_parse_url( home_url( add_query_arg( null, null ) ), PHP_URL_PATH );
        if ( ! $path ) {
            $path = '/';
        }
        return rtrim( $path, '/' ) ?: '/';
    }

    private function i18n( $lang ) {
        $strings = array(
            'nl' => array(
                'header_title'      => 'Visual Review',
                'view_mode'         => 'Bekijken',
                'edit_mode'         => 'Bewerken',
                'language'          => 'Taal',
                'add_pin'           => 'Pin plaatsen',
                'add_area'          => 'Gebied tekenen',
                'add_general'       => 'Algemeen',
                'cancel'            => 'Annuleren',
                'placing_pin'       => 'Klik op de pagina om een pin te plaatsen',
                'placing_area'      => 'Sleep om een gebied te selecteren',
                'placeholder_note'  => 'Beschrijf wat hier moet veranderen…',
                'placeholder_name'  => 'Jouw naam (optioneel)',
                'save'              => 'Opslaan',
                'delete'            => 'Verwijderen',
                'resolve'           => 'Markeer als opgelost',
                'reopen'            => 'Heropenen',
                'open'              => 'Open',
                'resolved'          => 'Opgelost',
                'no_reviews'        => 'Nog geen opmerkingen op deze pagina.',
                'reviews_count'     => 'opmerkingen',
                'powered_by'        => 'Online Heroes',
                'confirm_delete'    => 'Deze opmerking verwijderen?',
                'edit_required'     => 'Je bekijkt de review (alleen-lezen modus).',
                'translation_pending' => '(Nog geen vertaling beschikbaar)',
                'viewport_desktop'  => 'Desktop',
                'viewport_tablet'   => 'Tablet',
                'viewport_mobile'   => 'Mobiel',
            ),
            'en' => array(
                'header_title'      => 'Visual Review',
                'view_mode'         => 'View',
                'edit_mode'         => 'Edit',
                'language'          => 'Language',
                'add_pin'           => 'Place pin',
                'add_area'          => 'Draw area',
                'add_general'       => 'General',
                'cancel'            => 'Cancel',
                'placing_pin'       => 'Click on the page to place a pin',
                'placing_area'      => 'Drag to select an area',
                'placeholder_note'  => 'Describe what needs to change…',
                'placeholder_name'  => 'Your name (optional)',
                'save'              => 'Save',
                'delete'            => 'Delete',
                'resolve'           => 'Mark as resolved',
                'reopen'            => 'Reopen',
                'open'              => 'Open',
                'resolved'          => 'Resolved',
                'no_reviews'        => 'No comments on this page yet.',
                'reviews_count'     => 'comments',
                'powered_by'        => 'Online Heroes',
                'confirm_delete'    => 'Delete this comment?',
                'edit_required'     => 'You are in view mode (read-only).',
                'translation_pending' => '(No translation available yet)',
                'viewport_desktop'  => 'Desktop',
                'viewport_tablet'   => 'Tablet',
                'viewport_mobile'   => 'Mobile',
            ),
        );
        return $strings[ $lang ] ?? $strings['nl'];
    }
}
