<?php
/**
 * REST API endpoints voor Visual Review.
 *
 * Authenticatie:
 * - View mode: openbaar (zodra plugin enabled is).
 * - Edit mode (write/delete): vereist matching X-VR-Edit-Code header.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VR_REST {

    const NAMESPACE = 'visual-review/v1';

    public function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
    }

    public function register_routes() {
        register_rest_route( self::NAMESPACE, '/reviews', array(
            array(
                'methods'             => 'GET',
                'callback'            => array( $this, 'list_reviews' ),
                'permission_callback' => array( $this, 'permission_view' ),
                'args'                => array(
                    'path' => array( 'required' => true, 'type' => 'string' ),
                    'lang' => array( 'required' => false, 'type' => 'string', 'default' => 'nl' ),
                ),
            ),
            array(
                'methods'             => 'POST',
                'callback'            => array( $this, 'create_review' ),
                'permission_callback' => array( $this, 'permission_edit' ),
            ),
        ) );

        register_rest_route( self::NAMESPACE, '/reviews/(?P<id>\d+)', array(
            array(
                'methods'             => 'PUT',
                'callback'            => array( $this, 'update_review' ),
                'permission_callback' => array( $this, 'permission_edit' ),
            ),
            array(
                'methods'             => 'PATCH',
                'callback'            => array( $this, 'update_review' ),
                'permission_callback' => array( $this, 'permission_edit' ),
            ),
            array(
                'methods'             => 'DELETE',
                'callback'            => array( $this, 'delete_review' ),
                'permission_callback' => array( $this, 'permission_edit' ),
            ),
        ) );
    }

    /* -------- Permissions -------- */

    public function permission_view( $request ) {
        if ( ! VR_Settings::is_enabled() ) {
            return new WP_Error( 'vr_disabled', 'Visual Review is uitgeschakeld.', array( 'status' => 403 ) );
        }
        return true;
    }

    public function permission_edit( $request ) {
        if ( ! VR_Settings::is_enabled() ) {
            return new WP_Error( 'vr_disabled', 'Visual Review is uitgeschakeld.', array( 'status' => 403 ) );
        }

        // WP admins mogen altijd
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }

        $code     = $request->get_header( 'x_vr_edit_code' );
        $expected = VR_Settings::get_edit_code();

        if ( ! $code || ! hash_equals( $expected, $code ) ) {
            return new WP_Error( 'vr_forbidden', 'Ongeldige edit code.', array( 'status' => 403 ) );
        }
        return true;
    }

    /* -------- Helpers -------- */

    private function valid_lang( $lang ) {
        return in_array( $lang, array( 'nl', 'en' ), true ) ? $lang : 'nl';
    }

    private function format_review( $row, $lang = 'nl' ) {
        $lang = $this->valid_lang( $lang );
        $note = ( 'en' === $lang ) ? $row->note_en : $row->note_nl;

        $viewport = isset( $row->viewport ) && $row->viewport ? $row->viewport : 'desktop';
        if ( ! in_array( $viewport, array( 'desktop', 'tablet', 'mobile' ), true ) ) {
            $viewport = 'desktop';
        }

        return array(
            'id'              => (int) $row->id,
            'page_url'        => $row->page_url,
            'page_path'       => $row->page_path,
            'marker_type'     => $row->marker_type,
            'viewport'        => $viewport,
            'anchor_selector' => $row->anchor_selector,
            'x_percent'       => (float) $row->x_percent,
            'y_percent'       => (float) $row->y_percent,
            'width_percent'   => null !== $row->width_percent ? (float) $row->width_percent : null,
            'height_percent'  => null !== $row->height_percent ? (float) $row->height_percent : null,
            'viewport_width'  => null !== $row->viewport_width ? (int) $row->viewport_width : null,
            'note'            => $note,
            'note_nl'         => $row->note_nl,
            'note_en'         => $row->note_en,
            'author_name'     => $row->author_name,
            'status'          => $row->status,
            'lang'            => $lang,
            'created_at'      => $row->created_at,
            'updated_at'      => $row->updated_at,
        );
    }

    /* -------- Endpoints -------- */

    public function list_reviews( $request ) {
        $path = sanitize_text_field( $request->get_param( 'path' ) );
        $lang = $this->valid_lang( $request->get_param( 'lang' ) );

        $rows = VR_Database::get_for_path( $path );
        $out  = array_map( function( $row ) use ( $lang ) {
            return $this->format_review( $row, $lang );
        }, $rows );

        return rest_ensure_response( $out );
    }

    public function create_review( $request ) {
        $lang = $this->valid_lang( $request->get_param( 'lang' ) );
        $params = $request->get_json_params();

        $note     = isset( $params['note'] ) ? wp_kses_post( $params['note'] ) : '';
        $viewport = isset( $params['viewport'] ) && in_array( $params['viewport'], array( 'desktop', 'tablet', 'mobile' ), true )
            ? $params['viewport']
            : 'desktop';

        $data = array(
            'page_url'        => esc_url_raw( $params['page_url'] ?? '' ),
            'page_path'       => sanitize_text_field( $params['page_path'] ?? '/' ),
            'marker_type'     => in_array( ( $params['marker_type'] ?? 'pin' ), array( 'pin', 'area', 'general' ), true )
                                    ? $params['marker_type']
                                    : 'pin',
            'viewport'        => $viewport,
            'anchor_selector' => isset( $params['anchor_selector'] ) ? sanitize_text_field( $params['anchor_selector'] ) : null,
            'x_percent'       => isset( $params['x_percent'] ) ? floatval( $params['x_percent'] ) : 0,
            'y_percent'       => isset( $params['y_percent'] ) ? floatval( $params['y_percent'] ) : 0,
            'width_percent'   => isset( $params['width_percent'] ) ? floatval( $params['width_percent'] ) : null,
            'height_percent'  => isset( $params['height_percent'] ) ? floatval( $params['height_percent'] ) : null,
            'viewport_width'  => isset( $params['viewport_width'] ) ? intval( $params['viewport_width'] ) : null,
            'author_name'     => isset( $params['author_name'] ) ? sanitize_text_field( $params['author_name'] ) : null,
            'status'          => 'open',
        );

        // Schrijf de note naar de juiste taal-kolom
        if ( 'en' === $lang ) {
            $data['note_en'] = $note;
        } else {
            $data['note_nl'] = $note;
        }

        $id = VR_Database::insert( $data );
        if ( ! $id ) {
            return new WP_Error( 'vr_insert_failed', 'Opslaan mislukt.', array( 'status' => 500 ) );
        }

        $row = VR_Database::get( $id );
        return rest_ensure_response( $this->format_review( $row, $lang ) );
    }

    public function update_review( $request ) {
        $id   = intval( $request['id'] );
        $row  = VR_Database::get( $id );
        if ( ! $row ) {
            return new WP_Error( 'vr_not_found', 'Niet gevonden.', array( 'status' => 404 ) );
        }

        $lang   = $this->valid_lang( $request->get_param( 'lang' ) );
        $params = $request->get_json_params();
        $update = array();

        if ( array_key_exists( 'note', $params ) ) {
            $note = wp_kses_post( $params['note'] );
            if ( 'en' === $lang ) {
                $update['note_en'] = $note;
            } else {
                $update['note_nl'] = $note;
            }
        }

        if ( ! empty( $params['status'] ) && in_array( $params['status'], array( 'open', 'resolved' ), true ) ) {
            $update['status'] = $params['status'];
        }

        if ( isset( $params['author_name'] ) ) {
            $update['author_name'] = sanitize_text_field( $params['author_name'] );
        }

        if ( ! empty( $update ) ) {
            VR_Database::update( $id, $update );
        }

        $row = VR_Database::get( $id );
        return rest_ensure_response( $this->format_review( $row, $lang ) );
    }

    public function delete_review( $request ) {
        $id = intval( $request['id'] );
        VR_Database::delete( $id );
        return rest_ensure_response( array( 'deleted' => true, 'id' => $id ) );
    }
}
