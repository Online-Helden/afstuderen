<?php
/**
 * Settings helper.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VR_Settings {

    const OPTION_KEY = 'vr_settings';

    public static function defaults() {
        return array(
            'enabled'        => false,
            'edit_code'      => '',
            'ai_endpoint'    => 'https://helium-shiny-pony.ngrok-free.dev/v1/chat/completions',
            'ai_model'       => 'qwen3.5-9b',
            'ai_prompt'      => self::default_prompt(),
        );
    }

    /**
     * Standaard master prompt voor de vertaling.
     * Bewust kort gehouden — lokaal model heeft beperkt context window.
     */
    public static function default_prompt() {
        return "You translate Dutch web design feedback into clear English instructions for a freelance developer.\n\nRules:\n- Translate the instruction itself to English.\n- Keep literal website content (quoted text the client wants on the page) in its original language.\n- Be concise and actionable.\n- Output ONLY valid JSON: {\"translation\": \"...\"}";
    }

    public static function get_all() {
        $opts = get_option( self::OPTION_KEY, array() );
        return wp_parse_args( $opts, self::defaults() );
    }

    public static function get( $key, $default = null ) {
        $all = self::get_all();
        return isset( $all[ $key ] ) ? $all[ $key ] : $default;
    }

    public static function update( $values ) {
        $current = self::get_all();
        $merged  = wp_parse_args( $values, $current );
        update_option( self::OPTION_KEY, $merged );
    }

    public static function is_enabled() {
        return (bool) self::get( 'enabled', false );
    }

    public static function get_edit_code() {
        $code = self::get( 'edit_code' );
        if ( empty( $code ) ) {
            $code = VR_Database::generate_code();
            self::update( array( 'edit_code' => $code ) );
        }
        return $code;
    }
}
